# Building A2 | Wind lateral design basis

Northern Divide Data Campus, Lewis and Clark County, Montana. Delegated ASD wind package for EOR review. Grid X is east (longitudinal) and Y is north (transverse); origin at the southwest corner. The six perimeter walls resist in their own planes; the deck transfers normal wall reactions to those resisting lines through roof fasteners, chords, collectors and E1 embeds. Existing foundation restraint is represented by fixed-base panel legs. Seismic, gravity framing, out-of-plane panel/door/screen design and roof equipment are excluded.

| item | value | source |
|---|---|---|
| Kzt | 1.19 | TS-2026-02 §4 |
| Ke | 0.867045 | EOR-NDDC-A2-S01 Rev 2 §4.4; ALTA-2025-77 §1 BM-2 |
| q_h_psf | 28.7447 | EOR Rev 2 §4.2; NDDC-AHJ-014 §2; mean roof 28 ft |
| screen_wall_top_ft | 36.00 | SR-2026-118 §5.2; IFC N108–N111 |
| asbuilt_opening_panel | S14 | IFC S14-O1 / Pset_OpeningCommon |
| asd_combination | 0.6W | EOR Rev 2 §3.3 |
| omega_d | 2.35 | CDS-B36 Note 2 |
| analysis_method | DIAPH-MT 1.0 semi-rigid | EOR Rev 2 §9; NDDC-AHJ-014 §3 |
| mesh_level | L2 | EOR Rev 2 §§9.1, 9.7; H = 5 ft |

The governing scenario below maximizes the magnitude of the roof-to-wall in-plane reaction for each line.

| line | governing scenario |
|---|---|
| S | W07 |
| E | W10 |
| N1 | W06 |
| W | W01 |
| N2 | W03 |
| E2 | W01 |

## Document reconciliation

- **Wind criteria and analysis.** T-204 and NDDC-AHJ-014 supersede the preliminary 2024 hazard review and criteria Rev 0: use 115 mph, Risk Category III (not 105 mph/II), Exposure C, and the site-specific 1.19 topographic multiplier rather than 1.00. Use the ALTA BM-2 benchmark (3941.02 ft NAVD 88) for elevation correction, not unity; use the 3940.00 ft project finish-floor datum only to reference structural elevations. Use DIAPH-MT rather than the Rev 0 rigid distribution or a flexible tributary method. Hall B is another building, not a source of coefficients, geometry or design parameters for A2.
- **Plan set-out.** A-101 Rev A's rectangle is obsolete. Follow the 2026 IFC and corroborating A-101 Rev C; clip the northeast 60 ft by 40 ft yard notch and deduct the 40 ft by 30 ft mechanical well. In S-201 the Z43 label and grid rectangle do not set the takeoff; clip it to the actual roof per Note 8. Deduct the well from Z22, Z23, Z32 and Z33. Only the six IFC perimeter faces receive wall pressures and pier springs, including the two notch elevations. Mechanical well edges carry collectors but no wall springs.
- **Precast top and openings.** The 2024 PC-S01 schedule and preliminary uniform +31 ft tops do not govern. Scan SR-2026-118 and the IFC confirm deck +28 ft, typical panel +31 ft, and solid precast screen +36 ft over x=96–168 ft on N1 (N108–N111), consistent with A-301 Rev C. Use the scan/model elevations for pressure and gross weight, but not to increase pier height. The fabrication elevations PC-S02 Rev 2 and the 2024 schedule omit post-erection field cut S14-O1, from station 194.5 to 202.5 ft, sill 0 to head 12 ft. Use IFC geometry: the 2.5 ft leg is active, the 1.5 ft leg is omitted. Rev 1 is superseded. Fabrication openings shown on current elevations agree with the model and still receive gross-area pressure via their surrounding framing.
- **Pressure convention.** WT-2026-07 §3 describes the mean-roof reference; its more specific §6.3 and EOR §6.1 require top-of-panel velocity pressure for net parapet coefficients. No second height correction to wall Cp; no additional notch amplification or separate internal pressure term in the MWFRS. Parapet centroid above the deck gives opposite-sense normal base reaction and an amplified roof reaction.
- **Framing spacing and deck catalogue.** SJ-201 Note 1 states 5 ft typical joist spacing but 6 ft typical deck span. Use 5 ft for framing smear as confirmed by S-201 and SJ-201 Framing; retain unadjusted 6 ft reference catalogue G-prime outside Z22 (no 5 ft interpolation specified). In Z22 use 4 ft joist spacing and deck span per SJ-201 Note 2 and S-201 mechanical-bay callout, and apply the 1.15 stiffness multiplier, not a capacity increase. Deck strength uses the nominal-to-ASD conversion; plate and connection catalogues already give ASD values.
- **Serviceability and jurisdiction.** The project's adopted 2021 IBC / ASCE 7-16 and AHJ Risk Category III govern, not a wholesale adoption of UFC code/risk tables. The UFC Table 2-1 limits are for framing supporting exterior finishes; they do not replace the specific 0.55 in in-plane diaphragm relative-displacement limit and h/400 pier drift check of Rev 2. UFC's C&C deflection load note is not substituted for the project's 0.6W MWFRS basis.
- **Analysis interpretation.** Apply the length-averaged roof line load from §6.4 using the consistent nodal forces of §9.5. Case 2 takes the axis projection of the factored force for torque; all line loads are scaled by 0.75. At exact pier-node ties select the even grid index to reproduce VE-1. At exact station-cell ties select the cell with the lower along-wall coordinate. For connections, use the sum of in-plane pier forces on each panel. E1 and T1 counts in `Piers` are panel totals repeated for each leg, not additive by row. B1 hardware is existing and included in the panel price.
