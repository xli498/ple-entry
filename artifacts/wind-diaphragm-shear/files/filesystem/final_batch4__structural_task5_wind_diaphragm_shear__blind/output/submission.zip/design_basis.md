# Wind diaphragm and shear wall design basis — v11 / final_v11

All design demands below are ASD (0.6W), recovered from the coupled semi-rigid diaphragm model at L2. The spreadsheets, drawing and calculation package use this same design.

| item | value | source |
|---|---|---|
| Kzt | 1.19 | TS-2026-02 section 4 |
| Ke | 0.867077 | ALTA-2025-77 elevation 3940 ft; exp(-0.0000362 z) |
| q_h_psf | 28.7458 | Current criteria / WT-2026-07 wind pressures |
| screen_wall_top_ft | 36 | 2026 federated model and SR-2026-118 section 5.2 |
| asbuilt_opening_panel | S14 | PC-S02 note 4; field-cut opening in federated model |
| asd_combination | 0.6W | Current criteria section 3.3 |
| omega_d | 2.35 | CDS-B36 note 2 |
| analysis_method | semi-rigid diaphragm | Orthotropic membrane, axial chord bars and pier springs |
| mesh_level | L2 | 5 ft square elements; 1584 elements excluding opening |

## Governing Scenario per Wall Line

| line | governing scenario | ASD reaction (kips) |
|---|---|---|
| S | W07 | 34.78076658 |
| E | W10 | 22.31469996 |
| N2 | W03 | 22.73237433 |
| E2 | W01 | 48.07330653 |
| N1 | W07 | 22.95747761 |
| W | W01 | 44.57148972 |

## Geometry and resolved source conflicts

The current 2026 federated model controls the L-shaped footprint: (0,0), (240,0), (240,140), (180,140), (180,180), (0,180) ft. The 40,800 sf gross footprint excludes the 1,200 sf opening at x=100–140, y=100–130 ft, leaving 39,600 sf of deck.
Roof elevation is 28 ft. Standard panel top is 31 ft; the N1 screen wall reaches 36 ft at x=96–168 ft. A-301 note 2 states 31 ft; the scan/model resolves the screen-wall conflict to 36 ft. The field-cut S14 opening is included. Piers narrower than 2 ft are neglected; all remaining 73 piers are explicitly modeled.
Current criteria Rev 2 and AHJ letter govern V=115 mph and Kzt=1.19. Rev 0 values V=105 mph and Kzt=1.0 are superseded. The 2026 as-built footprint governs over superseded architectural geometry.

## Analysis and load path

Wind-tunnel patch coefficients are applied at each scenario azimuth. Wall pressure uses q_h; parapet/screen pressure uses q(z_top). A patch of height dz and centroid zc transfers roof line load p*dz*zc/28. Thus the above-roof cantilever lever is included explicitly. Case 2 uses factor 0.75 and eccentricity +/-0.15.
The orthotropic membrane uses EA_x=2900 and EA_y=13920 kip/ft; catalogue G-prime supplies shear stiffness. The mechanical zone at x=60–120, y=60–120 ft uses 1.15 times catalogue G-prime. Only Z22 has the 4 ft span designation. Axial bars use Es*A/H. Pier springs use k=1/[h^3/(3EcI)+1.2h/(GcA)] with h=336 in, Ec=4030 ksi and Gc=0.4Ec.
The global stiffness system is solved for all 12 scenarios. Element center shears, spring reactions and axial bar forces are recovered at ASD. Panel shear for F4–F6 is the sum of absolute pier reactions. Diaphragm deflection is relative to the stiffness-weighted mean support displacement, evaluated separately in X and Y.

## Deck assignments

| Zone | Deck | Area sf | G-prime used kip/in | ASD capacity plf | Max demand plf |
|---|---|---:|---:|---:|---:|
| Z11 | D22-36/4-4 | 3600 | 22.900000 | 527.659574 | 402.490269 |
| Z12 | D20-36/9-4 | 3600 | 46.100000 | 1268.085106 | 316.030582 |
| Z13 | D22-36/4-4 | 3600 | 22.900000 | 527.659574 | 384.261382 |
| Z21 | D22-36/4-4 | 3600 | 22.900000 | 527.659574 | 207.694022 |
| Z22 | D22-36/4-2 | 3200 | 20.470000 | 417.021277 | 135.633719 |
| Z23 | D22-36/4-2 | 3400 | 17.800000 | 417.021277 | 183.135976 |
| Z31 | D22-36/4-4 | 3600 | 22.900000 | 527.659574 | 222.643397 |
| Z32 | D22-36/7-4 | 3200 | 32.600000 | 842.553191 | 385.379484 |
| Z33 | D22-36/7-4 | 3400 | 32.600000 | 842.553191 | 770.944953 |
| Z41 | D22-36/7-4 | 3600 | 32.600000 | 842.553191 | 407.042078 |
| Z42 | D22-36/4-4 | 3600 | 22.900000 | 527.659574 | 227.403924 |
| Z43 | D22-36/4-4 | 1200 | 22.900000 | 527.659574 | 514.013205 |

## Chords and collectors

| Member | Section | Length ft |
|---|---|---:|
| C-S | PL3x3/8 | 240 |
| C-N1 | PL3x3/8 | 180 |
| C-N2 | PL3x3/8 | 60 |
| C-E | PL3x3/8 | 140 |
| C-E2 | PL12x1 | 40 |
| C-W | PL3x3/8 | 180 |
| K-N2 | PL3x3/8 | 180 |
| K-E2 | PL3x3/8 | 140 |
| O-S | PL3x3/8 | 40 |
| O-N | PL3x3/8 | 40 |
| O-W | PL3x3/8 | 30 |
| O-E | PL4x3/8 | 30 |

## Connections and checks

Provide 199 panel embed connections and 8 tiedown assemblies. Counts are per panel; repeated panel counts on individual pier rows are not additive. Tiedown panels: E201, E202, E203, E204, N112, N201, N202, N204.
For each panel, M_ot = V_panel*28. Resisting moment M_r = 0.6*W_panel*width/2 + 88*width when a tiedown is present. Weight uses the specified gross panel dimensions. The calculation package lists all panel demands and both tied/untied margins.
Maximum L2 diaphragm deflection is 0.546123823125 in in W01 Y; limit 0.55 in. E201 envelope shear is 13.983184825640 kips; limit 14.0 kips. All F1–F8 checks pass for all 12 scenarios.

## Mesh convergence

The key reaction is W01, wall line W, prescribed by current criteria section 9.7. L1/L2/L3 are genuine independent analyses of the same design. The L2/L3 relative reaction change is 0.216011795%, below 5%. L2 is the prescribed feasibility mesh; refinement results are reported without substituting them for L2.

| Level | H ft | Elements | Key reaction kips | Max shear plf | Max deflection in |
|---|---:|---:|---:|---:|---:|
| L1 | 10.0 | 396 | 44.374297675 | 544.602844 | 0.537900525173 |
| L2 | 5.0 | 1584 | 44.571489723 | 770.944953 | 0.546123823125 |
| L3 | 2.5 | 6336 | 44.667977824 | 1017.457743 | 0.550039896284 |

## Installed cost

| Category | Cost USD |
|---|---:|
| deck | 141720.00 |
| chord | 18513.32 |
| embed | 36815.00 |
| tiedown | 19600.00 |
| total | 216648.32 |

Costs use catalogue unit prices, measured areas/lengths and per-panel connection quantities. The $171,415.15 certified bound is a relaxed lower bound, not a constructible design or a claimed attainable cost.
