# 13.8 kV Medium-Voltage Conveyance Study (optimization v9)

Conveyance study for circuits C01–C07 (13.8 kV). All costs are the Class 3 engineer's estimate at the RFP roll-up (JOOH 9.5%, HOOH 4.5%, weighted-guidelines profit, bond, escalation to the construction midpoint, 5.0% design contingency, SIOH 5.7%). Labor hours are crew man-hours (MH) and labor rates are the loaded Davis-Bacon rates from Wage Determination CA20260022, Modification 5. The estimate uses area cost factor 1.0 (no ACF on a detailed take-off, UFS 3-701-01 4-1.1) and the governing sidewall bearing pressure of 600 lb/ft (approved submittal SUB-33 71 02-07).

## C01 — SS1-F1 to MB1-ERA

Recommended: CEDB concrete-encased ductbank. Route length 829.1 ft; total project cost $261,270.20; cost per linear foot $315.14 per LF. Labor hours 586.2 MH.

| Type | Admissible | Labor hours (MH) | Cost per LF ($/LF) | Total project cost ($) |
|---|---|---|---|---|
| CEDB concrete-encased ductbank **(recommended)** | Yes | 586.2 | 315.14 | 261,270.20 |
| UEDB unencased ductbank | No | 624.1 | 318.27 | 263,866.88 |
| DBC direct-buried cable | No | 343.5 | 168.71 | 139,869.04 |
| HDD horizontal directional drilling | No | 408.6 | 339.78 | 281,700.02 |
| OH overhead | No | 161.1 | 89.49 | 74,192.91 |

Labor rates are the loaded rates in the LaborRates sheet (base wage plus fringe and payroll burden). Admissibility in the table concerns the conveyance type; other types are comparative estimates and require a detailed compliant route before construction. The recommendation has the lowest total project cost among the permitted alternatives priced here.

Route composition: CE 769.1 ft; HDD 60.0 ft.
Cable: 500 kcmil aluminum, 2 parallel set(s); governing ampacity 331.5 A per set, 663.1 A total against a 640 A pickup. Manholes: 1.
Maximum calculated pull length 587.4 ft; maximum tension 1447.2 lb (limit 6000 lb); maximum sidewall pressure 40.7 lb/ft (limit 600 lb/ft).

## C02 — SS1-F2 to MB1-ERB

Recommended: CEDB concrete-encased ductbank. Route length 1070.8 ft; total project cost $319,670.12; cost per linear foot $298.53 per LF. Labor hours 737.7 MH.

| Type | Admissible | Labor hours (MH) | Cost per LF ($/LF) | Total project cost ($) |
|---|---|---|---|---|
| CEDB concrete-encased ductbank **(recommended)** | Yes | 737.7 | 298.53 | 319,670.12 |
| UEDB unencased ductbank | No | 761.6 | 301.25 | 322,580.06 |
| DBC direct-buried cable | No | 412.2 | 161.24 | 172,653.68 |
| HDD horizontal directional drilling | No | 512.1 | 410.36 | 439,425.14 |
| OH overhead | No | 185.0 | 78.11 | 83,640.25 |

Labor rates are the loaded rates in the LaborRates sheet (base wage plus fringe and payroll burden). Admissibility in the table concerns the conveyance type; other types are comparative estimates and require a detailed compliant route before construction. The recommendation has the lowest total project cost among the permitted alternatives priced here.

Route composition: CE 1010.8 ft; HDD 60.0 ft.
Cable: 500 kcmil aluminum, 2 parallel set(s); governing ampacity 315.3 A per set, 630.6 A total against a 560 A pickup. Manholes: 1.
Maximum calculated pull length 585.5 ft; maximum tension 2224.5 lb (limit 6000 lb); maximum sidewall pressure 47.7 lb/ft (limit 600 lb/ft).

## C03 — SS1-F3 to CUP1-S

Recommended: CEDB concrete-encased ductbank. Route length 403.8 ft; total project cost $60,959.74; cost per linear foot $150.97 per LF. Labor hours 166.8 MH.

| Type | Admissible | Labor hours (MH) | Cost per LF ($/LF) | Total project cost ($) |
|---|---|---|---|---|
| CEDB concrete-encased ductbank **(recommended)** | Yes | 166.8 | 150.97 | 60,959.74 |
| UEDB unencased ductbank | No | 153.1 | 153.24 | 61,876.99 |
| DBC direct-buried cable | No | 87.7 | 80.24 | 32,401.52 |
| HDD horizontal directional drilling | No | 113.3 | 273.64 | 110,493.05 |
| OH overhead | No | 92.2 | 107.11 | 43,249.65 |

Labor rates are the loaded rates in the LaborRates sheet (base wage plus fringe and payroll burden). Admissibility in the table concerns the conveyance type; other types are comparative estimates and require a detailed compliant route before construction. The recommendation has the lowest total project cost among the permitted alternatives priced here.

Route composition: CE 403.8 ft.
Cable: 350 kcmil aluminum, 1 parallel set(s); governing ampacity 410.1 A per set, 410.1 A total against a 400 A pickup. Manholes: 0.
Maximum calculated pull length 403.8 ft; maximum tension 2808.7 lb (limit 4200 lb); maximum sidewall pressure 510.4 lb/ft (limit 600 lb/ft).

## C04 — CUP1-E to TX-LS2

Recommended: OH overhead. Route length 1478.3 ft; total project cost $163,204.92; cost per linear foot $110.40 per LF. Labor hours 394.1 MH.

| Type | Admissible | Labor hours (MH) | Cost per LF ($/LF) | Total project cost ($) |
|---|---|---|---|---|
| CEDB concrete-encased ductbank | Yes | 719.8 | 167.27 | 247,269.88 |
| UEDB unencased ductbank | No | 633.1 | 165.40 | 244,507.95 |
| DBC direct-buried cable | No | 344.0 | 74.20 | 109,691.90 |
| HDD horizontal directional drilling | No | 343.3 | 227.18 | 335,841.04 |
| OH overhead **(recommended)** | Yes | 394.1 | 110.40 | 163,204.92 |

Labor rates are the loaded rates in the LaborRates sheet (base wage plus fringe and payroll burden). Admissibility in the table concerns the conveyance type; other types are comparative estimates and require a detailed compliant route before construction. The recommendation has the lowest total project cost among the permitted alternatives priced here.

Route composition: CE 634.7 ft; HDD 60.0 ft; OH 783.6 ft.
Cable: 250 kcmil aluminum, 1 parallel set(s); governing ampacity 196.0 A per set, 196.0 A total against a 60 A pickup. Manholes: 1.
Overhead conductor: ACSR 1/0 AWG; ampacity 196.0 A.
Maximum calculated pull length 495.4 ft; maximum tension 1081.9 lb (limit 3000 lb); maximum sidewall pressure 32.1 lb/ft (limit 600 lb/ft).
C04 uses 694.7 ft underground and 783.6 ft overhead (53.0% overhead). The first riser at (1160, 865) is outside the congested area; the overhead spans clear the channel, and the final riser is at TX-LS2. One manhole divides the underground pulls.

## C05 — MSG-A to USS-A1

Recommended: RMC rigid metal conduit. Route length 322.8 ft; total project cost $170,330.02; cost per linear foot $527.66 per LF. Labor hours 443.1 MH.

| Type | Admissible | Labor hours (MH) | Cost per LF ($/LF) | Total project cost ($) |
|---|---|---|---|---|
| RMC rigid metal conduit **(recommended)** | Yes | 443.1 | 527.66 | 170,330.02 |
| EMT electrical metallic tubing | No | 352.8 | 328.00 | 105,879.18 |
| TRAY-EN enclosed cable tray | No | 370.5 | 383.53 | 123,802.33 |
| TRAY-LD ladder cable tray | No | 351.1 | 339.36 | 109,545.36 |

Labor rates are the loaded rates in the LaborRates sheet (base wage plus fringe and payroll burden). Admissibility in the table concerns the conveyance type; other types are comparative estimates and require a detailed compliant route before construction. The recommendation has the lowest total project cost among the permitted alternatives priced here.

Route composition: RMC 322.8 ft.
Cable: 250 kcmil aluminum, 2 parallel set(s); governing ampacity 160.0 A per set, 320.0 A total against a 200 A pickup. Manholes: 0.
Maximum calculated pull length 322.8 ft; maximum tension 1376.1 lb (limit 3000 lb); maximum sidewall pressure 241.3 lb/ft (limit 600 lb/ft).

## C06 — SS1-F4 to TX-GH1

Recommended: OH overhead. Route length 1795.5 ft; total project cost $131,143.41; cost per linear foot $73.04 per LF. Labor hours 295.0 MH.

| Type | Admissible | Labor hours (MH) | Cost per LF ($/LF) | Total project cost ($) |
|---|---|---|---|---|
| CEDB concrete-encased ductbank | Yes | 695.4 | 148.99 | 267,503.73 |
| UEDB unencased ductbank | No | 628.6 | 150.09 | 269,484.96 |
| DBC direct-buried cable | No | 301.7 | 60.28 | 108,238.71 |
| HDD horizontal directional drilling | No | 411.1 | 181.09 | 325,150.21 |
| OH overhead **(recommended)** | Yes | 295.0 | 73.04 | 131,143.41 |

Labor rates are the loaded rates in the LaborRates sheet (base wage plus fringe and payroll burden). Admissibility in the table concerns the conveyance type; other types are comparative estimates and require a detailed compliant route before construction. The recommendation has the lowest total project cost among the permitted alternatives priced here.

Route composition: CE 181.6 ft; OH 1613.9 ft.
Cable: 250 kcmil aluminum, 1 parallel set(s); governing ampacity 196.0 A per set, 196.0 A total against a 40 A pickup. Manholes: 1.
Overhead conductor: ACSR 1/0 AWG; ampacity 196.0 A.
Maximum calculated pull length 105.4 ft; maximum tension 313.6 lb (limit 3000 lb); maximum sidewall pressure 32.1 lb/ft (limit 600 lb/ft).

## C07 — CUP1-N to TX-W3

Recommended: CEDB concrete-encased ductbank. Route length 766.0 ft; total project cost $118,537.16; cost per linear foot $154.75 per LF. Labor hours 287.1 MH.

| Type | Admissible | Labor hours (MH) | Cost per LF ($/LF) | Total project cost ($) |
|---|---|---|---|---|
| CEDB concrete-encased ductbank **(recommended)** | Yes | 287.1 | 154.75 | 118,537.16 |
| UEDB unencased ductbank | No | 400.5 | 197.76 | 151,488.29 |
| DBC direct-buried cable | No | 230.4 | 89.43 | 68,501.59 |
| HDD horizontal directional drilling | No | 190.8 | 271.06 | 207,633.51 |
| OH overhead | No | 124.7 | 72.29 | 55,376.28 |

Labor rates are the loaded rates in the LaborRates sheet (base wage plus fringe and payroll burden). Admissibility in the table concerns the conveyance type; other types are comparative estimates and require a detailed compliant route before construction. The recommendation has the lowest total project cost among the permitted alternatives priced here.

Route composition: CE 706.0 ft; HDD 60.0 ft.
Cable: 250 kcmil aluminum, 1 parallel set(s); governing ampacity 291.6 A per set, 291.6 A total against a 120 A pickup. Manholes: 1.
Maximum calculated pull length 598.4 ft; maximum tension 1144.9 lb (limit 3000 lb); maximum sidewall pressure 32.1 lb/ft (limit 600 lb/ft).
