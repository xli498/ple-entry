# Pacific Crest Space Force Annex
## 13.8 kV conveyance study | pre-35% decision package
FA4610-26-R-0031 | PCSFA 24-0117 | September 15, 2026

This study compares each method required by Section 01 11 00 Amendment 0002. Excluded alternatives are priced for comparison; they are not buildable designs. Coordinates and plan distances are in site feet.

| Item | Selected type | Route ft | Direct $ | Total project $ | Project $/ft |
|---|---|---:|---:|---:|---:|
| C01 | CEDB | 861.4 | 190,654 | 269,774 | 313.17 |
| C02 | CEDB | 1,162.1 | 264,899 | 374,831 | 322.54 |
| C03 | CEDB | 503.9 | 74,323 | 105,166 | 208.70 |
| C04 | CEDB | 1,217.0 | 184,411 | 260,941 | 214.42 |
| C05 | RMC | 400.0 | 149,454 | 211,477 | 528.69 |
| C06 | OH | 1,830.3 | 126,065 | 178,382 | 97.46 |
| C07 | CEDB | 660.0 | 140,332 | 198,569 | 300.86 |
| **Combined** | | | **1,130,138** | **1,599,140** | |
## Executive decision

The recommended package total is approximately $1,130,138 direct before the live workbook roll-up. The recommendation is the lowest cost route among methods the criteria permit, not simply the lowest arithmetic alternative.

### Design basis
- IEDS Rev 3 controls precedence over superseded documents; approved TD-15AL-133 Rev 3 controls cable limits, including 600 lb/ft sidewall pressure.
- Site primary is 15 kV class, 133% MV-105 aluminum, copper tape shield. Cable sets are three single conductors in one duct/raceway.
- Minimum underground cover is 18 in, 24 in beneath pavement, 50 in below top of active rail, and HDD top-of-conduit is 48 in beneath pavement or 120 in elsewhere.
- Soil is planning Type B except Type C below groundwater or in granular/unstable conditions; any excavation at least 5 ft deep is protected.
- C05 route stays south of the SCIF 10-ft keep-out and uses the available MR-2/ER-A spaces; open cable tray alternatives are rejected where the enclosure/access envelope cannot be maintained.

### Cost method
The workbook contains formula-driven direct cost and markup roll-up. Quantities use the RFP 3.7 conventions, the PCEC 2026 labor-unit database and crew compositions, WD CA20260022 Mod 5, EP Region VII rates adjusted from the invoice fuel prices, supplier Q-2608-114 with waste and sales tax, and the three quoted subcontractors. C05 is priced as interior work.

## C01 | SS-1 F1 to MSG-A
**Recommendation: CEDB.** West entry to MSG-A. The Mission Drive bore passes below W-12. The northern corridor avoids the retained oak at (520,655), reduces exposure to B-3 thermal soil and maintains separation from the Bus B route.

| Type | Allowed | Route ft | Labor mh | Labor $ | Equipment $ | Materials $ | Subcontracts $ | Direct $ | Project $ | Project $/ft |
|---|:---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| CEDB | Y | 861.4 | 608.11 | 52,065.16 | 10,646.88 | 113,941.60 | 14,000.00 | 190,653.63 | 269,774.09 | 313.17 |
| UEDB | N | 861.4 | 567.18 | 48,752.65 | 10,990.57 | 126,742.79 | 14,000.00 | 200,486.01 | 283,686.86 | 329.32 |
| DBC | N | 861.4 | 335.43 | 28,992.79 | 6,931.02 | 80,561.78 | 14,000.00 | 130,485.60 | 184,636.57 | 214.34 |
| HDD | N | 861.4 | 456.96 | 39,524.48 | 10,364.43 | 100,034.99 | 141,593.43 | 291,517.32 | 412,495.79 | 478.85 |
| OH | N | 826.1 | 380.50 | 33,309.31 | 7,880.54 | 66,732.99 | 0.00 | 107,922.84 | 152,710.37 | 184.86 |

- **CEDB:** PCSFA-IEDS Rev 3 §§4.2–4.5, 4.8; UFC 3-550-01 C3 §3-11.2. Concrete encasement is predominant; trenchless crossing exceptions only.
- **UEDB:** PCSFA-IEDS Rev 3 §4.2 bars primary distribution in unencased conduit.
- **DBC:** PCSFA-IEDS Rev 3 §4.2 bars direct burial on primary distribution; UFC 3-550-01 C3 §3-11.3.1 requires Activity approval for limited use.
- **HDD:** PCSFA-IEDS Rev 3 §§4.3, 4.14 and UFC 3-550-01 C3 §3-11.4.1 allow HDD only at qualifying crossings. No compliant full-run HDD alignment.
- **OH:** PCSFA-IEDS Rev 3 §4.1 and UFC 3-550-01 C3 §3-11.1.1: usable direct corridor is in the industrial area; no listed single ACSR phase conductor meets pickup.

**Electrical basis:** 2 set(s) of 500 aluminum; 640 A phase pickup; 16.5 kA for 0.5 s versus 33.3 kA cable withstand per set. Governing MV cable ampacity 331.55 A/set (B-3, CE, 18 in cover, resistivity bracket 150 C·cm/W where underground).

| Segment | Method | Alignment (site ft) | Cover in | Duct rows × cols / size | Spare | Rebar | Soil | Protection | Dewater |
|---:|---|---|---:|---|---:|:---:|:---:|---|:---:|
| 1 | CE | 280,640; 400,640 | 18 | 1×3 / 5 in | 1 | N | B | none | N |
| 2 | CE | 400,640; 460,700 | 18 | 1×3 / 5 in | 1 | N | B | none | N |
| 3 | CE | 460,700; 585,700 | 18 | 1×3 / 5 in | 1 | N | B | none | N |
| 4 | CE | 585,700; 670,700 | 18 | 1×3 / 5 in | 1 | N | B | none | N |
| 5 | CE | 670,700; 706.607143,700 | 18 | 1×3 / 5 in | 1 | N | B | none | N |
| 6 | CE | 706.607143,700; 750,700 | 18 | 1×3 / 5 in | 1 | N | B | none | N |
| 7 | HDD | 750,700; 800,700 | 84 | 1×4 / 6 in | 2 | N | B | box | N |
| 8 | CE | 800,700; 870,700 | 18 | 1×3 / 5 in | 1 | N | B | none | N |
| 9 | CE | 870,700; 910,740 | 18 | 1×3 / 5 in | 1 | N | B | none | N |
| 10 | CE | 910,740; 950,740 | 18 | 1×3 / 5 in | 1 | N | B | none | N |
| 11 | CE | 950,740; 1095,740 | 18 | 1×3 / 5 in | 1 | N | B | none | N |
| 12 | CE | 1095,740; 1100,740 | 18 | 1×3 / 5 in | 1 | N | B | none | N |

| Structure | Kind | x ft | y ft | Height ft | Guys | Dead end | Excavation |
|---|---|---:|---:|---:|---:|:---:|---|
| MH1 | MH | 670 | 700 | – | – | – | box |

| Pull | From | To | Plan ft | Max tension lb | SWBP lb/ft | Minimum D/d | Max fill % |
|---|---|---|---:|---:|---:|---:|---:|
| P1 | START | MH1 | 414.85 | 1537.35 | 40.71 | 3.21 | 29.13 |
| P2 | END | MH1 | 446.57 | 1701.44 | 40.71 | 3.21 | 29.13 |

**Rate references:** adjusted rates for every priced code are in Appendix A. The following table identifies all labor, equipment, and material line codes used per alternative; takeoff quantities and dollars are in the workbook.

| Type | Labor codes | Equipment IDs | Material/subcontract codes |
|---|---|---|---|
| CEDB | EX-MACH, BF-COMP, DUCT-CE, GND-DB, CONC-PL, TAPE, MH-SET, MH-BASE, TBOX, FIREPROOF, PULL-MV-L, TERM-MV | C10BO003, C80TE008, H25CA040, L50CA001, RQ-BDT, RQ-PUL, RQ-TBX | EX-MACH, BF-COMP, EB20-5, SPACER, GND-4/0, CONC-3000, TAPE, TAPE-DET, MH-SET, MH-PRECAST, MH-BASE, ROCK-BASE, TBOX, FIRETAPE, PULL-MV-L, CBL-500, TERM-KIT |
| UEDB | EX-MACH, BF-COMP, DUCT-UE, GND-DB, SAND-BED, TAPE, MH-SET, MH-BASE, TBOX, FIREPROOF, PULL-MV-L, TERM-MV | C10BO003, C80TE008, H25CA040, L50CA001, RQ-BDT, RQ-PUL, RQ-TBX | EX-MACH, BF-COMP, SCH40-6, SPACER, GND-4/0, SAND-BED, SAND, TAPE, TAPE-DET, MH-SET, MH-PRECAST, MH-BASE, ROCK-BASE, TBOX, FIRETAPE, PULL-MV-L, CBL-500, TERM-KIT |
| DBC | EX-TRCH, BF-COMP, SAND-BED, TAPE, EX-MACH, MH-SET, MH-BASE, TBOX, FIREPROOF, DBC-LAY, PULL-MV-L, TERM-MV | C10BO003, C80TE008, H25CA040, L50CA001, RQ-BDT, RQ-PUL, RQ-TBX, T30DW022 | EX-TRCH, BF-COMP, SAND-BED, SAND, TAPE, TAPE-DET, EX-MACH, MH-SET, MH-PRECAST, MH-BASE, ROCK-BASE, TBOX, FIRETAPE, DBC-LAY, PULL-MV-L, CBL-500, TERM-KIT |
| HDD | EX-MACH, BF-COMP, MH-SET, MH-BASE, TBOX, FIREPROOF, PULL-MV-L, TERM-MV | C10BO003, C80TE008, H25CA040, L50CA001, RQ-BDT, RQ-PUL, RQ-TBX | EX-MACH, BF-COMP, MH-SET, MH-PRECAST, MH-BASE, ROCK-BASE, TBOX, FIRETAPE, PULL-MV-L, CBL-750, TERM-KIT |
| OH | EX-MACH, BF-COMP, DUCT-CE, GND-DB, CONC-PL, TAPE, PULL-MV-L, TERM-MV, POLE-SET, POLE-HOLE, XARM, GUY, RISER, STRING | C10BO003, H25CA040, L50CA001, RQ-BDT, RQ-PUL | EX-MACH, BF-COMP, EB20-5, SPACER, GND-4/0, CONC-3000, TAPE, TAPE-DET, PULL-MV-L, CBL-500, TERM-KIT, POLE-SET, POLE-45, POLE-HOLE, XARM, XARM-ASSY, GUY, GUY-ASSY, POLE-50, RISER, RISER-ASSY, STRING, ACSR-477 |

## C02 | SS-1 F2 to MSG-B
**Recommendation: CEDB.** South entry to MSG-B. Cross Mission Drive below W-12, drop below T-2 where the alignment turns southeast, cross above SD-30 and enter perpendicular to the building wall. Keep the Bus B feeder separate from Bus A outside the 50-ft exceptions.

| Type | Allowed | Route ft | Labor mh | Labor $ | Equipment $ | Materials $ | Subcontracts $ | Direct $ | Project $ | Project $/ft |
|---|:---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| CEDB | Y | 1,162.1 | 832.53 | 71,202.39 | 14,662.27 | 165,034.29 | 14,000.00 | 264,898.94 | 374,830.90 | 322.54 |
| UEDB | N | 1,162.1 | 776.24 | 66,646.17 | 15,130.46 | 182,579.57 | 14,000.00 | 278,356.19 | 393,872.84 | 338.92 |
| DBC | N | 1,162.1 | 456.02 | 39,346.85 | 9,527.84 | 105,404.17 | 14,000.00 | 168,278.86 | 238,113.88 | 204.89 |
| HDD | N | 1,162.1 | 620.12 | 53,574.96 | 14,152.50 | 117,658.17 | 186,460.62 | 371,846.26 | 526,160.90 | 452.75 |
| OH | N | 1,054.8 | 419.71 | 36,714.32 | 8,734.01 | 69,617.09 | 0.00 | 115,065.42 | 162,817.09 | 154.37 |

- **CEDB:** PCSFA-IEDS Rev 3 §§4.2–4.5, 4.8; UFC 3-550-01 C3 §3-11.2. Concrete encasement is predominant; trenchless crossing exceptions only.
- **UEDB:** PCSFA-IEDS Rev 3 §4.2 bars primary distribution in unencased conduit.
- **DBC:** PCSFA-IEDS Rev 3 §4.2 bars direct burial on primary distribution; UFC 3-550-01 C3 §3-11.3.1 requires Activity approval for limited use.
- **HDD:** PCSFA-IEDS Rev 3 §§4.3, 4.14 and UFC 3-550-01 C3 §3-11.4.1 allow HDD only at qualifying crossings. No compliant full-run HDD alignment.
- **OH:** PCSFA-IEDS Rev 3 §4.1 and UFC 3-550-01 C3 §3-11.1.1: usable direct corridor is in the industrial area; no listed single ACSR phase conductor meets pickup.

**Electrical basis:** 2 set(s) of 500 aluminum; 560 A phase pickup; 16.5 kA for 0.5 s versus 33.3 kA cable withstand per set. Governing MV cable ampacity 331.55 A/set (B-3, CE, 18 in cover, resistivity bracket 150 C·cm/W where underground).

| Segment | Method | Alignment (site ft) | Cover in | Duct rows × cols / size | Spare | Rebar | Soil | Protection | Dewater |
|---:|---|---|---:|---|---:|:---:|:---:|---|:---:|
| 1 | CE | 280,520; 360,520 | 18 | 1×3 / 5 in | 1 | N | B | none | N |
| 2 | CE | 360,520; 400,480 | 18 | 1×3 / 5 in | 1 | N | B | none | N |
| 3 | CE | 400,480; 475,480 | 18 | 1×3 / 5 in | 1 | N | B | none | N |
| 4 | CE | 475,480; 670,480 | 18 | 1×3 / 5 in | 1 | N | B | none | N |
| 5 | CE | 670,480; 750,480 | 18 | 1×3 / 5 in | 1 | N | B | none | N |
| 6 | HDD | 750,480; 800,480 | 84 | 1×4 / 6 in | 2 | N | B | box | N |
| 7 | CE | 800,480; 808.75,480 | 18 | 1×3 / 5 in | 1 | N | B | none | N |
| 8 | CE | 808.75,480; 864,480 | 18 | 1×3 / 5 in | 1 | N | B | none | N |
| 9 | CE | 864,480; 920,480 | 18 | 1×3 / 5 in | 1 | N | B | none | N |
| 10 | CE | 920,480; 930.555556,469.444444 | 18 | 1×3 / 5 in | 1 | N | B | none | N |
| 11 | CE | 930.555556,469.444444; 940,460 | 18 | 1×3 / 5 in | 1 | N | B | none | N |
| 12 | CE | 940,460; 998,402 | 61 | 1×3 / 5 in | 1 | N | B | box | N |
| 13 | CE | 998,402; 1030,370 | 18 | 1×3 / 5 in | 1 | N | B | none | N |
| 14 | CE | 1030,370; 1200,370 | 18 | 1×3 / 5 in | 1 | N | B | none | N |
| 15 | CE | 1200,370; 1259.5,370 | 18 | 1×3 / 5 in | 1 | N | B | none | N |
| 16 | CE | 1259.5,370; 1330,370 | 18 | 1×3 / 5 in | 1 | N | B | none | N |
| 17 | CE | 1330,370; 1330,415 | 18 | 1×3 / 5 in | 1 | N | B | none | N |
| 18 | CE | 1330,415; 1330,420 | 18 | 1×3 / 5 in | 1 | N | B | none | N |

| Structure | Kind | x ft | y ft | Height ft | Guys | Dead end | Excavation |
|---|---|---:|---:|---:|---:|:---:|---|
| MH1 | MH | 670 | 480 | – | – | – | box |
| MH2 | MH | 1200 | 370 | – | – | – | box |

| Pull | From | To | Plan ft | Max tension lb | SWBP lb/ft | Minimum D/d | Max fill % |
|---|---|---|---:|---:|---:|---:|---:|
| P1 | START | MH1 | 406.57 | 1417.28 | 40.71 | 3.21 | 29.13 |
| P2 | MH2 | MH1 | 575.56 | 1794.50 | 31.92 | 3.21 | 29.13 |
| P3 | END | MH2 | 180.00 | 861.93 | 40.71 | 3.21 | 29.13 |

**Rate references:** adjusted rates for every priced code are in Appendix A. The following table identifies all labor, equipment, and material line codes used per alternative; takeoff quantities and dollars are in the workbook.

| Type | Labor codes | Equipment IDs | Material/subcontract codes |
|---|---|---|---|
| CEDB | EX-MACH, BF-COMP, DUCT-CE, GND-DB, CONC-PL, TAPE, TBOX, MH-SET, MH-BASE, FIREPROOF, PULL-MV-L, TERM-MV | C10BO003, C80TE008, H25CA040, L50CA001, RQ-BDT, RQ-PUL, RQ-TBX | EX-MACH, BF-COMP, EB20-5, SPACER, GND-4/0, CONC-3000, TAPE, TAPE-DET, TBOX, MH-SET, MH-PRECAST, MH-BASE, ROCK-BASE, FIRETAPE, PULL-MV-L, CBL-500, TERM-KIT |
| UEDB | EX-MACH, BF-COMP, DUCT-UE, GND-DB, SAND-BED, TAPE, TBOX, MH-SET, MH-BASE, FIREPROOF, PULL-MV-L, TERM-MV | C10BO003, C80TE008, H25CA040, L50CA001, RQ-BDT, RQ-PUL, RQ-TBX | EX-MACH, BF-COMP, SCH40-6, SPACER, GND-4/0, SAND-BED, SAND, TAPE, TAPE-DET, TBOX, MH-SET, MH-PRECAST, MH-BASE, ROCK-BASE, FIRETAPE, PULL-MV-L, CBL-500, TERM-KIT |
| DBC | EX-TRCH, BF-COMP, SAND-BED, TAPE, TBOX, EX-MACH, MH-SET, MH-BASE, FIREPROOF, DBC-LAY, PULL-MV-L, TERM-MV | C10BO003, C80TE008, H25CA040, L50CA001, RQ-BDT, RQ-PUL, RQ-TBX, T30DW022 | EX-TRCH, BF-COMP, SAND-BED, SAND, TAPE, TAPE-DET, TBOX, EX-MACH, MH-SET, MH-PRECAST, MH-BASE, ROCK-BASE, FIRETAPE, DBC-LAY, PULL-MV-L, CBL-350, TERM-KIT |
| HDD | EX-MACH, BF-COMP, MH-SET, MH-BASE, TBOX, FIREPROOF, PULL-MV-L, TERM-MV | C10BO003, C80TE008, H25CA040, L50CA001, RQ-BDT, RQ-PUL, RQ-TBX | EX-MACH, BF-COMP, MH-SET, MH-PRECAST, MH-BASE, ROCK-BASE, TBOX, FIRETAPE, PULL-MV-L, CBL-500, TERM-KIT |
| OH | EX-MACH, BF-COMP, DUCT-CE, GND-DB, CONC-PL, TAPE, PULL-MV-L, TERM-MV, POLE-SET, POLE-HOLE, XARM, GUY, RISER, STRING | C10BO003, H25CA040, L50CA001, RQ-BDT, RQ-PUL | EX-MACH, BF-COMP, EB20-5, SPACER, GND-4/0, CONC-3000, TAPE, TAPE-DET, PULL-MV-L, CBL-350, TERM-KIT, POLE-SET, POLE-45, POLE-HOLE, XARM, XARM-ASSY, GUY, GUY-ASSY, POLE-50, RISER, RISER-ASSY, STRING, ACSR-477 |

## C03 | SS-1 F3 to SWG-C1
**Recommendation: CEDB.** Enter the CUP-1 south wall via the west side of P-1. Skirt the T-202 root zone on the east, locate the pull manhole diagonally clear of the parking corner, and pass west of the G-4 endpoint before turning east 15 ft north of the pipe.

| Type | Allowed | Route ft | Labor mh | Labor $ | Equipment $ | Materials $ | Subcontracts $ | Direct $ | Project $ | Project $/ft |
|---|:---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| CEDB | Y | 503.9 | 232.33 | 19,857.29 | 3,559.48 | 50,905.93 | 0.00 | 74,322.70 | 105,166.31 | 208.70 |
| UEDB | N | 503.9 | 216.25 | 18,561.71 | 3,722.26 | 59,351.14 | 0.00 | 81,635.11 | 115,513.34 | 229.24 |
| DBC | N | 503.9 | 133.05 | 11,482.57 | 2,405.59 | 35,345.37 | 0.00 | 49,233.54 | 69,665.26 | 138.25 |
| HDD | N | 503.9 | 165.04 | 14,273.69 | 3,416.03 | 37,749.93 | 105,960.00 | 161,399.65 | 228,379.83 | 453.22 |
| OH | N | 347.1 | 154.28 | 13,579.81 | 3,256.31 | 26,738.24 | 0.00 | 43,574.36 | 61,657.54 | 177.62 |

- **CEDB:** PCSFA-IEDS Rev 3 §§4.2–4.5, 4.8; UFC 3-550-01 C3 §3-11.2. Concrete encasement is predominant; trenchless crossing exceptions only.
- **UEDB:** PCSFA-IEDS Rev 3 §4.2 bars primary distribution in unencased conduit.
- **DBC:** PCSFA-IEDS Rev 3 §4.2 bars direct burial on primary distribution; UFC 3-550-01 C3 §3-11.3.1 requires Activity approval for limited use.
- **HDD:** PCSFA-IEDS Rev 3 §§4.3, 4.14 and UFC 3-550-01 C3 §3-11.4.1 allow HDD only at qualifying crossings. No compliant full-run HDD alignment.
- **OH:** PCSFA-IEDS Rev 3 §4.1 and UFC 3-550-01 C3 §3-11.1.1: usable direct corridor is in the industrial area.

**Electrical basis:** 1 set(s) of 350 aluminum; 400 A phase pickup; 16.5 kA for 0.5 s versus 23.3 kA cable withstand per set. Governing MV cable ampacity 410.12 A/set (B-1, CE, 18 in cover, resistivity bracket 90 C·cm/W where underground).

| Segment | Method | Alignment (site ft) | Cover in | Duct rows × cols / size | Spare | Rebar | Soil | Protection | Dewater |
|---:|---|---|---:|---|---:|:---:|:---:|---|:---:|
| 1 | CE | 240,700; 240,730 | 18 | 1×2 / 5 in | 1 | N | B | none | N |
| 2 | CE | 240,730; 270,760 | 18 | 1×2 / 5 in | 1 | N | B | none | N |
| 3 | CE | 270,760; 270,851.875 | 18 | 1×2 / 5 in | 1 | N | B | none | N |
| 4 | CE | 270,851.875; 270,875 | 18 | 1×2 / 5 in | 1 | N | B | none | N |
| 5 | CE | 270,875; 245,920 | 18 | 1×2 / 5 in | 1 | N | B | none | N |
| 6 | CE | 245,920; 245,935 | 18 | 1×2 / 5 in | 1 | N | B | none | N |
| 7 | CE | 245,935; 470,935 | 18 | 1×2 / 5 in | 1 | N | B | none | N |
| 8 | CE | 470,935; 470,960 | 18 | 1×2 / 5 in | 1 | N | B | none | N |

| Structure | Kind | x ft | y ft | Height ft | Guys | Dead end | Excavation |
|---|---|---:|---:|---:|---:|:---:|---|
| MH1 | MH | 245 | 935 | – | – | – | box |

| Pull | From | To | Plan ft | Max tension lb | SWBP lb/ft | Minimum D/d | Max fill % |
|---|---|---|---:|---:|---:|---:|---:|
| P1 | START | MH1 | 253.90 | 1232.61 | 35.38 | 3.51 | 24.37 |
| P2 | END | MH1 | 250.00 | 786.49 | 35.38 | 3.51 | 24.37 |

**Rate references:** adjusted rates for every priced code are in Appendix A. The following table identifies all labor, equipment, and material line codes used per alternative; takeoff quantities and dollars are in the workbook.

| Type | Labor codes | Equipment IDs | Material/subcontract codes |
|---|---|---|---|
| CEDB | EX-MACH, BF-COMP, DUCT-CE, GND-DB, CONC-PL, TAPE, MH-SET, MH-BASE, TBOX, FIREPROOF, PULL-MV-L, TERM-MV | C10BO003, C80TE008, H25CA040, L50CA001, RQ-BDT, RQ-PUL, RQ-TBX | EX-MACH, BF-COMP, EB20-5, SPACER, GND-4/0, CONC-3000, TAPE, TAPE-DET, MH-SET, MH-PRECAST, MH-BASE, ROCK-BASE, TBOX, FIRETAPE, PULL-MV-L, CBL-350, TERM-KIT |
| UEDB | EX-MACH, BF-COMP, DUCT-UE, GND-DB, SAND-BED, TAPE, MH-SET, MH-BASE, TBOX, FIREPROOF, PULL-MV-L, TERM-MV | C10BO003, C80TE008, H25CA040, L50CA001, RQ-BDT, RQ-PUL, RQ-TBX | EX-MACH, BF-COMP, SCH40-6, SPACER, GND-4/0, SAND-BED, SAND, TAPE, TAPE-DET, MH-SET, MH-PRECAST, MH-BASE, ROCK-BASE, TBOX, FIRETAPE, PULL-MV-L, CBL-500, TERM-KIT |
| DBC | EX-TRCH, BF-COMP, SAND-BED, TAPE, EX-MACH, MH-SET, MH-BASE, TBOX, FIREPROOF, DBC-LAY, PULL-MV-L, TERM-MV | C10BO003, C80TE008, H25CA040, L50CA001, RQ-BDT, RQ-PUL, RQ-TBX, T30DW022 | EX-TRCH, BF-COMP, SAND-BED, SAND, TAPE, TAPE-DET, EX-MACH, MH-SET, MH-PRECAST, MH-BASE, ROCK-BASE, TBOX, FIRETAPE, DBC-LAY, PULL-MV-L, CBL-350, TERM-KIT |
| HDD | EX-MACH, BF-COMP, MH-SET, MH-BASE, TBOX, FIREPROOF, PULL-MV-L, TERM-MV | C10BO003, C80TE008, H25CA040, L50CA001, RQ-BDT, RQ-PUL, RQ-TBX | EX-MACH, BF-COMP, MH-SET, MH-PRECAST, MH-BASE, ROCK-BASE, TBOX, FIRETAPE, PULL-MV-L, CBL-500, TERM-KIT |
| OH | EX-MACH, BF-COMP, DUCT-CE, GND-DB, CONC-PL, TAPE, PULL-MV-L, TERM-MV, POLE-SET, POLE-HOLE, XARM, GUY, RISER, STRING | C10BO003, H25CA040, L50CA001, RQ-BDT, RQ-PUL | EX-MACH, BF-COMP, EB20-5, SPACER, GND-4/0, CONC-3000, TAPE, TAPE-DET, PULL-MV-L, CBL-350, TERM-KIT, POLE-SET, POLE-45, POLE-HOLE, XARM, XARM-ASSY, GUY, GUY-ASSY, RISER, RISER-ASSY, STRING, ACSR-336.4 |

## C04 | CUP-1 CF-2 to TX-LS2
**Recommendation: CEDB.** Leave CUP-1 through the east wall. Reinforce the service-yard bank and extend it 5 ft past the pavement. Bore Mission Drive below W-12 and cross SD-30 above the storm drain. The DC-1 crossing is a deep HDD with pits outside the 25-ft channel buffer.

| Type | Allowed | Route ft | Labor mh | Labor $ | Equipment $ | Materials $ | Subcontracts $ | Direct $ | Project $ | Project $/ft |
|---|:---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| CEDB | Y | 1,217.0 | 522.92 | 44,552.65 | 8,417.62 | 103,441.13 | 28,000.00 | 184,411.40 | 260,941.36 | 214.42 |
| UEDB | N | 1,217.0 | 488.12 | 41,734.56 | 8,673.41 | 106,832.49 | 28,000.00 | 185,240.45 | 262,114.47 | 215.38 |
| DBC | N | 1,217.0 | 333.97 | 28,613.65 | 6,221.57 | 73,854.81 | 28,000.00 | 136,690.03 | 193,415.82 | 158.93 |
| HDD | N | 1,217.0 | 347.93 | 30,014.30 | 7,786.34 | 66,510.05 | 176,534.61 | 280,845.30 | 397,394.93 | 326.54 |
| OH | Y | 1,403.8 | 539.25 | 46,517.85 | 9,776.90 | 138,956.41 | 14,000.00 | 209,251.16 | 296,089.51 | 210.91 |

- **CEDB:** PCSFA-IEDS Rev 3 §§4.2–4.5, 4.8; UFC 3-550-01 C3 §3-11.2. Concrete encasement is predominant; trenchless crossing exceptions only.
- **UEDB:** PCSFA-IEDS Rev 3 §4.2 bars primary distribution in unencased conduit.
- **DBC:** PCSFA-IEDS Rev 3 §4.2 bars direct burial on primary distribution; UFC 3-550-01 C3 §3-11.3.1 requires Activity approval for limited use.
- **HDD:** PCSFA-IEDS Rev 3 §§4.3, 4.14 and UFC 3-550-01 C3 §3-11.4.1 allow HDD only at qualifying crossings. No compliant full-run HDD alignment.
- **OH:** PCSFA-IEDS Rev 3 §§4.1, 4.9: overhead corridor east of the industrial area with south-side approach north of MB-1, encased risers and a channel span.

**Electrical basis:** 1 set(s) of 250 aluminum; 60 A phase pickup; 14.2 kA for 0.5 s versus 16.6 kA cable withstand per set. Governing MV cable ampacity 330.48 A/set (B-8, CE, 18 in cover, resistivity bracket 120 C·cm/W where underground).

| Segment | Method | Alignment (site ft) | Cover in | Duct rows × cols / size | Spare | Rebar | Soil | Protection | Dewater |
|---:|---|---|---:|---|---:|:---:|:---:|---|:---:|
| 1 | CE | 600,1030; 705,1030 | 24 | 1×2 / 5 in | 1 | Y | C | none | N |
| 2 | CE | 705,1030; 750,1030 | 18 | 1×2 / 5 in | 1 | N | B | none | N |
| 3 | HDD | 750,1030; 800,1030 | 84 | 1×2 / 5 in | 1 | N | C | box | Y |
| 4 | CE | 800,1030; 825,1030 | 18 | 1×2 / 5 in | 1 | N | B | none | N |
| 5 | CE | 825,1030; 865,1070 | 18 | 1×2 / 5 in | 1 | N | B | none | N |
| 6 | CE | 865,1070; 948.934426,1070 | 18 | 1×2 / 5 in | 1 | N | B | none | N |
| 7 | CE | 948.934426,1070; 1110,1070 | 18 | 1×2 / 5 in | 1 | N | B | none | N |
| 8 | CE | 1110,1070; 1120,1070 | 18 | 1×2 / 5 in | 1 | N | B | none | N |
| 9 | CE | 1120,1070; 1320,1070 | 18 | 1×2 / 5 in | 1 | N | B | none | N |
| 10 | CE | 1320,1070; 1348.235294,1101.764706 | 18 | 1×2 / 5 in | 1 | N | B | none | N |
| 11 | CE | 1348.235294,1101.764706; 1400,1160 | 18 | 1×2 / 5 in | 1 | N | B | none | N |
| 12 | CE | 1400,1160; 1565,1160 | 18 | 1×2 / 5 in | 1 | N | B | none | N |
| 13 | CE | 1565,1160; 1568,1160 | 18 | 1×2 / 5 in | 1 | N | B | none | N |
| 14 | HDD | 1568,1160; 1672,1160 | 120 | 1×2 / 5 in | 1 | N | B | box | N |
| 15 | CE | 1672,1160; 1760,1160 | 18 | 1×2 / 5 in | 1 | N | B | none | N |

| Structure | Kind | x ft | y ft | Height ft | Guys | Dead end | Excavation |
|---|---|---:|---:|---:|---:|:---:|---|
| MH1 | MH | 1110 | 1070 | – | – | – | box |
| MH2 | MH | 1565 | 1160 | – | – | – | box |

| Pull | From | To | Plan ft | Max tension lb | SWBP lb/ft | Minimum D/d | Max fill % |
|---|---|---|---:|---:|---:|---:|---:|
| P1 | START | MH1 | 526.57 | 1232.25 | 32.06 | 3.27 | 27.99 |
| P2 | MH2 | MH1 | 495.42 | 1029.68 | 15.84 | 3.79 | 20.93 |
| P3 | END | MH2 | 195.00 | 408.65 | 32.06 | 3.27 | 27.99 |

**Rate references:** adjusted rates for every priced code are in Appendix A. The following table identifies all labor, equipment, and material line codes used per alternative; takeoff quantities and dollars are in the workbook.

| Type | Labor codes | Equipment IDs | Material/subcontract codes |
|---|---|---|---|
| CEDB | EX-MACH, BF-COMP, DUCT-CE, GND-DB, CONC-PL, REBAR, TAPE, PAVE-CUT, MH-SET, MH-BASE, TBOX, FIREPROOF, PULL-MV-L, TERM-MV | C10BO003, C80TE008, H25CA040, L50CA001, RQ-BDT, RQ-PUL, RQ-TBX | EX-MACH, BF-COMP, EB20-5, SPACER, GND-4/0, CONC-3000, REBAR-4, TAPE, TAPE-DET, PAVE-CUT, ASPHALT, MH-SET, MH-PRECAST, MH-BASE, ROCK-BASE, TBOX, FIRETAPE, PULL-MV-L, CBL-250, TERM-KIT |
| UEDB | EX-MACH, BF-COMP, DUCT-CE, GND-DB, CONC-PL, REBAR, TAPE, PAVE-CUT, DUCT-UE, SAND-BED, MH-SET, MH-BASE, TBOX, FIREPROOF, PULL-MV-L, TERM-MV | C10BO003, C80TE008, H25CA040, L50CA001, RQ-BDT, RQ-PUL, RQ-TBX | EX-MACH, BF-COMP, EB20-5, SPACER, GND-4/0, CONC-3000, REBAR-4, TAPE, TAPE-DET, PAVE-CUT, ASPHALT, SCH40-5, SAND-BED, SAND, MH-SET, MH-PRECAST, MH-BASE, ROCK-BASE, TBOX, FIRETAPE, PULL-MV-L, CBL-250, TERM-KIT |
| DBC | EX-MACH, BF-COMP, DUCT-CE, GND-DB, CONC-PL, REBAR, TAPE, PAVE-CUT, EX-TRCH, SAND-BED, MH-SET, MH-BASE, TBOX, FIREPROOF, DBC-LAY, PULL-MV-L, TERM-MV | C10BO003, C80TE008, H25CA040, L50CA001, RQ-BDT, RQ-PUL, RQ-TBX, T30DW022 | EX-MACH, BF-COMP, EB20-5, SPACER, GND-4/0, CONC-3000, REBAR-4, TAPE, TAPE-DET, PAVE-CUT, ASPHALT, EX-TRCH, SAND-BED, SAND, MH-SET, MH-PRECAST, MH-BASE, ROCK-BASE, TBOX, FIRETAPE, DBC-LAY, PULL-MV-L, CBL-250, TERM-KIT |
| HDD | EX-MACH, BF-COMP, MH-SET, MH-BASE, TBOX, FIREPROOF, PULL-MV-L, TERM-MV | C10BO003, C80TE008, H25CA040, L50CA001, RQ-BDT, RQ-PUL, RQ-TBX | EX-MACH, BF-COMP, MH-SET, MH-PRECAST, MH-BASE, ROCK-BASE, TBOX, FIRETAPE, PULL-MV-L, CBL-250, TERM-KIT |
| OH | EX-MACH, BF-COMP, DUCT-CE, GND-DB, CONC-PL, REBAR, TAPE, PAVE-CUT, TBOX, MH-SET, MH-BASE, DEWATER, FIREPROOF, PULL-MV-L, TERM-MV, POLE-SET, POLE-HOLE, XARM, GUY, RISER, STRING | C10BO003, C80TE008, H25CA040, L50CA001, P50WC002, RQ-BDT, RQ-PUL, RQ-TBX | EX-MACH, BF-COMP, EB20-5, SPACER, GND-4/0, CONC-3000, REBAR-4, TAPE, TAPE-DET, PAVE-CUT, ASPHALT, TBOX, MH-SET, MH-PRECAST, MH-BASE, ROCK-BASE, DEWATER, FIRETAPE, PULL-MV-L, CBL-250, TERM-KIT, POLE-SET, POLE-45, POLE-HOLE, XARM, XARM-ASSY, GUY, GUY-ASSY, RISER, RISER-ASSY, STRING, ACSR-1/0 |

## C05 | MSG-A A-3 to USS-A1
**Recommendation: RMC.** Run south in ER-A and east through MR-2 at y=655, crossing two 2-hour boundaries before terminating at USS-A1. Provide 5-in RGS firestopped at both rated walls; support at 10 ft maximum and brace at 40 ft transverse / 80 ft longitudinal.

| Type | Allowed | Route ft | Labor mh | Labor $ | Equipment $ | Materials $ | Subcontracts $ | Direct $ | Project $ | Project $/ft |
|---|:---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| RMC | Y | 400.0 | 536.55 | 54,783.59 | 2,939.06 | 91,731.70 | 0.00 | 149,454.35 | 211,477.28 | 528.69 |
| EMT | N | 400.0 | 425.59 | 43,468.91 | 2,284.45 | 47,749.62 | 0.00 | 93,502.98 | 132,306.32 | 330.77 |
| TRAY-EN | N | 400.0 | 426.31 | 43,541.51 | 2,288.65 | 55,154.09 | 0.00 | 100,984.25 | 142,892.29 | 357.23 |
| TRAY-LD | N | 400.0 | 402.31 | 41,094.04 | 2,147.05 | 45,266.24 | 0.00 | 88,507.33 | 125,237.50 | 313.09 |

- **RMC:** PCSFA-IEDS Rev 3 §§5.1–5.3; UFC 3-520-01 (2025) Table 3-1; UFGS 26 20 00 §3.1.6. Six-inch vertical zone available through MR-2.
- **EMT:** UFGS 26 20 00 §3.1.6.2(c) and UFC 3-520-01 Table 3-1 exclude EMT where exposed to physical damage; equipment-room approaches are in replacement zones. Quoted 4-in EMT also does not give a compliant single-set 500 kcmil pull (over 40% fill).
- **TRAY-EN:** UFC 3-520-01 Table 3-1 permits enclosed tray in principle; PCSFA-IEDS Rev 3 §5.1 + A-501 Rev 1 require 18 in, but MR-2 has 16 in and COR-1D/COR-2 14 in. SCIF keep-out blocks northern bypass.
- **TRAY-LD:** UFC 3-520-01 Table 3-1, Article 328: interior MV must be in raceway or fully enclosed tray. A-501 Rev 1 also precludes the required access envelope.

**Electrical basis:** 2 set(s) of 250 aluminum; 200 A phase pickup; 15.8 kA for 0.5 s versus 16.6 kA cable withstand per set. Governing MV cable ampacity 160.00 A/set (40 C air, RMC, 0 in cover, resistivity bracket 0 C·cm/W where underground).

| Segment | Method | Alignment (site ft) | Cover in | Duct rows × cols / size | Spare | Rebar | Soil | Protection | Dewater |
|---:|---|---|---:|---|---:|:---:|:---:|---|:---:|
| 1 | RMC | 1130,730; 1130,655 | – | 1×2 / 5 in | 0 | N | – | – | N |
| 2 | RMC | 1130,655; 1280,655 | – | 1×2 / 5 in | 0 | N | – | – | N |
| 3 | RMC | 1280,655; 1440,655 | – | 1×2 / 5 in | 0 | N | – | – | N |
| 4 | RMC | 1440,655; 1440,640 | – | 1×2 / 5 in | 0 | N | – | – | N |

| Structure | Kind | x ft | y ft | Height ft | Guys | Dead end | Excavation |
|---|---|---:|---:|---:|---:|:---:|---|
| PB1 | PULLBOX | 1280 | 655 | – | – | – | – |

| Pull | From | To | Plan ft | Max tension lb | SWBP lb/ft | Minimum D/d | Max fill % |
|---|---|---|---:|---:|---:|---:|---:|
| P1 | START | PB1 | 225.00 | 867.26 | 116.29 | 3.63 | 22.76 |
| P2 | END | PB1 | 175.00 | 708.27 | 86.04 | 3.63 | 22.76 |

**Rate references:** adjusted rates for every priced code are in Appendix A. The following table identifies all labor, equipment, and material line codes used per alternative; takeoff quantities and dollars are in the workbook.

| Type | Labor codes | Equipment IDs | Material/subcontract codes |
|---|---|---|---|
| RMC | RMC-5, ELBOW-5, PBOX, FIRE-RMC, SEISMIC, PULL-IN, TERM-IN | RQ-LFT | RMC-5, RGS-5, ELBOW-5, ELBOW-RGS5, PBOX, PBOX-36, FIRE-RMC, FIRESTOP-RMC5, SEISMIC, SEISMIC-BR, PULL-IN, CBL-250, TERM-KIT |
| EMT | EMT-4, ELBOW-5, PBOX, FIRE-RMC, SEISMIC, PULL-IN, TERM-IN | RQ-LFT | EMT-4, EMT-4IN, ELBOW-5, ELBOW-RGS5, PBOX, PBOX-36, FIRE-RMC, FIRESTOP-RMC5, SEISMIC, SEISMIC-BR, PULL-IN, CBL-250, TERM-KIT |
| TRAY-EN | TRAY-24, TRAY-COV, TRAY-BOND, RMC-5, ELBOW-5, FIRE-SLV, SEISMIC, PULL-IN, TERM-IN | RQ-LFT | TRAY-24, TRAY-24-SB, TRAY-COV, TRAY-COV-24, TRAY-BOND, BOND-2, RMC-5, RGS-5, ELBOW-5, ELBOW-RGS5, FIRE-SLV, FIRE-SLV-4, SEISMIC, SEISMIC-BR, PULL-IN, CBL-250, TERM-KIT |
| TRAY-LD | TRAY-24, TRAY-BOND, RMC-5, ELBOW-5, FIRE-SLV, SEISMIC, PULL-IN, TERM-IN | RQ-LFT | TRAY-24, TRAY-24-LD, TRAY-BOND, BOND-2, RMC-5, RGS-5, ELBOW-5, ELBOW-RGS5, FIRE-SLV, FIRE-SLV-4, SEISMIC, SEISMIC-BR, PULL-IN, CBL-250, TERM-KIT |

## C06 | SS-1 F4 to TX-GH1
**Recommendation: OH.** Use the southern shoulder corridor north of Perimeter Road. Keep the primary underground inside the industrial area and connect the 1/0 ACSR line by dead-end riser poles. Fly Mission Drive on 50-ft poles; turn into the pad via the last pull manhole.

| Type | Allowed | Route ft | Labor mh | Labor $ | Equipment $ | Materials $ | Subcontracts $ | Direct $ | Project $ | Project $/ft |
|---|:---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| CEDB | Y | 1,849.7 | 814.54 | 69,382.62 | 13,107.72 | 194,939.93 | 14,000.00 | 291,430.27 | 412,372.61 | 222.94 |
| UEDB | N | 1,849.7 | 749.17 | 64,088.56 | 13,588.23 | 201,310.94 | 14,000.00 | 292,987.72 | 414,576.40 | 224.14 |
| DBC | N | 1,849.7 | 459.58 | 39,439.65 | 8,982.21 | 139,391.17 | 14,000.00 | 201,813.04 | 285,564.60 | 154.39 |
| HDD | N | 1,849.7 | 574.22 | 49,441.11 | 12,595.38 | 136,885.93 | 249,784.00 | 448,706.42 | 634,917.71 | 343.26 |
| OH | Y | 1,830.3 | 368.52 | 32,080.80 | 7,561.34 | 86,423.27 | 0.00 | 126,065.41 | 178,382.03 | 97.46 |

- **CEDB:** PCSFA-IEDS Rev 3 §§4.2–4.5, 4.8; UFC 3-550-01 C3 §3-11.2. Concrete encasement is predominant; trenchless crossing exceptions only.
- **UEDB:** PCSFA-IEDS Rev 3 §4.2 bars primary distribution in unencased conduit.
- **DBC:** PCSFA-IEDS Rev 3 §4.2 bars direct burial on primary distribution; UFC 3-550-01 C3 §3-11.3.1 requires Activity approval for limited use.
- **HDD:** PCSFA-IEDS Rev 3 §§4.3, 4.14 and UFC 3-550-01 C3 §3-11.4.1 allow HDD only at qualifying crossings. No compliant full-run HDD alignment.
- **OH:** PCSFA-IEDS Rev 3 §§4.1, 4.9; UFC 3-550-01 C3 §§3-10, 3-11.1.1: southern line outside industrial area, with encased approaches to both terminals.

**Electrical basis:** 1 set(s) of 250 aluminum; 40 A phase pickup; 16.5 kA for 0.5 s versus 16.6 kA cable withstand per set. Governing MV cable ampacity 330.48 A/set (B-12, CE, 18 in cover, resistivity bracket 120 C·cm/W where underground). Bare 1/0 ACSR ampacity 196 A at 40 °C.

| Segment | Method | Alignment (site ft) | Cover in | Duct rows × cols / size | Spare | Rebar | Soil | Protection | Dewater |
|---:|---|---|---:|---|---:|:---:|:---:|---|:---:|
| 1 | CE | 180,480; 194.939759,420.240964 | 18 | 1×2 / 5 in | 1 | N | B | none | N |
| 2 | CE | 194.939759,420.240964; 195,420 | 18 | 1×2 / 5 in | 1 | N | B | none | N |
| 3 | CE | 195,420; 195,350 | 18 | 1×2 / 5 in | 1 | N | B | none | N |
| 4 | CE | 195,350; 195,285 | 18 | 1×2 / 5 in | 1 | N | B | none | N |
| 5 | OH | 195,285; 450,240 | – | – | – | N | – | – | N |
| 6 | OH | 450,240; 735,200 | – | – | – | N | – | – | N |
| 7 | OH | 735,200; 815,190 | – | – | – | N | – | – | N |
| 8 | OH | 815,190; 1100,170 | – | – | – | N | – | – | N |
| 9 | OH | 1100,170; 1380,155 | – | – | – | N | – | – | N |
| 10 | OH | 1380,155; 1665,150 | – | – | – | N | – | – | N |
| 11 | OH | 1665,150; 1765,150 | – | – | – | N | – | – | N |
| 12 | CE | 1765,150; 1800,150 | 18 | 1×2 / 5 in | 1 | N | B | none | N |
| 13 | CE | 1800,150; 1800,130 | 18 | 1×2 / 5 in | 1 | N | B | none | N |

| Structure | Kind | x ft | y ft | Height ft | Guys | Dead end | Excavation |
|---|---|---:|---:|---:|---:|:---:|---|
| MH1 | MH | 195 | 350 | – | – | – | box |
| MH2 | MH | 1800 | 150 | – | – | – | box |
| RP1 | RISER_POLE | 195 | 285 | 45 | 1 | Y | – |
| O01 | POLE | 450 | 240 | 45 | 0 | N | – |
| O02 | POLE | 735 | 200 | 50 | 0 | N | – |
| O03 | POLE | 815 | 190 | 50 | 0 | N | – |
| O04 | POLE | 1100 | 170 | 45 | 0 | N | – |
| O05 | POLE | 1380 | 155 | 45 | 0 | N | – |
| O06 | POLE | 1665 | 150 | 45 | 0 | N | – |
| RP2 | RISER_POLE | 1765 | 150 | 45 | 1 | Y | – |

| Pull | From | To | Plan ft | Max tension lb | SWBP lb/ft | Minimum D/d | Max fill % |
|---|---|---|---:|---:|---:|---:|---:|
| P1 | START | MH1 | 131.85 | 372.32 | 32.06 | 3.79 | 20.93 |
| P2 | RP1 | MH1 | 65.00 | 266.42 | 32.06 | 3.79 | 20.93 |
| P3 | RP2 | MH2 | 35.00 | 231.35 | 32.06 | 3.79 | 20.93 |
| P4 | END | MH2 | 20.00 | 213.82 | 32.06 | 3.79 | 20.93 |

**Rate references:** adjusted rates for every priced code are in Appendix A. The following table identifies all labor, equipment, and material line codes used per alternative; takeoff quantities and dollars are in the workbook.

| Type | Labor codes | Equipment IDs | Material/subcontract codes |
|---|---|---|---|
| CEDB | EX-MACH, BF-COMP, DUCT-CE, GND-DB, CONC-PL, TAPE, MH-SET, MH-BASE, TBOX, FIREPROOF, PULL-MV-L, TERM-MV | C10BO003, C80TE008, H25CA040, L50CA001, RQ-BDT, RQ-PUL, RQ-TBX | EX-MACH, BF-COMP, EB20-5, SPACER, GND-4/0, CONC-3000, TAPE, TAPE-DET, MH-SET, MH-PRECAST, MH-BASE, ROCK-BASE, TBOX, FIRETAPE, PULL-MV-L, CBL-250, TERM-KIT |
| UEDB | EX-MACH, BF-COMP, DUCT-UE, GND-DB, SAND-BED, TAPE, MH-SET, MH-BASE, TBOX, FIREPROOF, PULL-MV-L, TERM-MV | C10BO003, C80TE008, H25CA040, L50CA001, RQ-BDT, RQ-PUL, RQ-TBX | EX-MACH, BF-COMP, SCH40-5, SPACER, GND-4/0, SAND-BED, SAND, TAPE, TAPE-DET, MH-SET, MH-PRECAST, MH-BASE, ROCK-BASE, TBOX, FIRETAPE, PULL-MV-L, CBL-250, TERM-KIT |
| DBC | EX-TRCH, BF-COMP, SAND-BED, TAPE, EX-MACH, MH-SET, MH-BASE, TBOX, FIREPROOF, DBC-LAY, PULL-MV-L, TERM-MV | C10BO003, C80TE008, H25CA040, L50CA001, RQ-BDT, RQ-PUL, RQ-TBX, T30DW022 | EX-TRCH, BF-COMP, SAND-BED, SAND, TAPE, TAPE-DET, EX-MACH, MH-SET, MH-PRECAST, MH-BASE, ROCK-BASE, TBOX, FIRETAPE, DBC-LAY, PULL-MV-L, CBL-250, TERM-KIT |
| HDD | EX-MACH, BF-COMP, MH-SET, MH-BASE, TBOX, FIREPROOF, PULL-MV-L, TERM-MV | C10BO003, C80TE008, H25CA040, L50CA001, RQ-BDT, RQ-PUL, RQ-TBX | EX-MACH, BF-COMP, MH-SET, MH-PRECAST, MH-BASE, ROCK-BASE, TBOX, FIRETAPE, PULL-MV-L, CBL-250, TERM-KIT |
| OH | EX-MACH, BF-COMP, DUCT-CE, GND-DB, CONC-PL, TAPE, MH-SET, MH-BASE, TBOX, FIREPROOF, PULL-MV-L, TERM-MV, POLE-SET, POLE-HOLE, XARM, GUY, RISER, STRING | C10BO003, C80TE008, H25CA040, L50CA001, RQ-BDT, RQ-PUL, RQ-TBX | EX-MACH, BF-COMP, EB20-5, SPACER, GND-4/0, CONC-3000, TAPE, TAPE-DET, MH-SET, MH-PRECAST, MH-BASE, ROCK-BASE, TBOX, FIRETAPE, PULL-MV-L, CBL-250, TERM-KIT, POLE-SET, POLE-45, POLE-HOLE, XARM, XARM-ASSY, GUY, GUY-ASSY, POLE-50, RISER, RISER-ASSY, STRING, ACSR-1/0 |

## C07 | CUP-1 CF-1 to TX-W3
**Recommendation: CEDB.** Exit CUP-1 north. Jack rigid galvanized steel through the 28.708-ft active-rail zone at 42 in below finished grade (50 in below top of rail); bore Mission Drive below the surveyed W-12. Follow the south side of W-3, then turn north at the east-side manhole.

| Type | Allowed | Route ft | Labor mh | Labor $ | Equipment $ | Materials $ | Subcontracts $ | Direct $ | Project $ | Project $/ft |
|---|:---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| CEDB | Y | 660.0 | 307.61 | 26,315.20 | 4,887.37 | 77,333.79 | 31,795.16 | 140,331.52 | 198,568.52 | 300.86 |
| UEDB | N | 660.0 | 286.50 | 24,605.22 | 5,042.58 | 79,391.62 | 31,795.16 | 140,834.58 | 199,280.34 | 301.94 |
| DBC | N | 660.0 | 192.96 | 16,643.63 | 3,554.84 | 59,383.64 | 31,795.16 | 111,377.27 | 157,598.37 | 238.79 |
| HDD | N | 660.0 | 229.99 | 19,874.10 | 4,721.89 | 58,574.45 | 130,611.16 | 213,781.60 | 302,500.07 | 458.33 |
| OH | N | 553.2 | 176.95 | 15,543.54 | 3,760.51 | 29,794.63 | 0.00 | 49,098.68 | 69,474.43 | 125.59 |

- **CEDB:** PCSFA-IEDS Rev 3 §§4.2–4.5, 4.8; UFC 3-550-01 C3 §3-11.2. Concrete encasement is predominant; trenchless crossing exceptions only.
- **UEDB:** PCSFA-IEDS Rev 3 §4.2 bars primary distribution in unencased conduit.
- **DBC:** PCSFA-IEDS Rev 3 §4.2 bars direct burial on primary distribution; UFC 3-550-01 C3 §3-11.3.1 requires Activity approval for limited use.
- **HDD:** PCSFA-IEDS Rev 3 §§4.3, 4.14 and UFC 3-550-01 C3 §3-11.4.1 allow HDD only at qualifying crossings. No compliant full-run HDD alignment.
- **OH:** PCSFA-IEDS Rev 3 §4.1 and UFC 3-550-01 C3 §3-11.1.1: usable direct corridor is in the industrial area and W-3 dock crane area.

**Electrical basis:** 1 set(s) of 250 aluminum; 120 A phase pickup; 14.2 kA for 0.5 s versus 16.6 kA cable withstand per set. Governing MV cable ampacity 330.48 A/set (B-8, CE, 18 in cover, resistivity bracket 120 C·cm/W where underground).

| Segment | Method | Alignment (site ft) | Cover in | Duct rows × cols / size | Spare | Rebar | Soil | Protection | Dewater |
|---:|---|---|---:|---|---:|:---:|:---:|---|:---:|
| 1 | CE | 490,1060; 490,1085.646 | 18 | 1×2 / 5 in | 1 | N | B | none | N |
| 2 | JB | 490,1085.646; 490,1114.354 | 42 | 1×2 / 5 in | 1 | N | C | box | N |
| 3 | CE | 490,1114.354; 490,1143 | 18 | 1×2 / 5 in | 1 | N | B | none | N |
| 4 | CE | 490,1143; 695,1143 | 18 | 1×2 / 5 in | 1 | N | B | none | N |
| 5 | CE | 695,1143; 750,1143 | 18 | 1×2 / 5 in | 1 | N | B | none | N |
| 6 | HDD | 750,1143; 800,1143 | 84 | 1×2 / 5 in | 1 | N | C | box | Y |
| 7 | CE | 800,1143; 958.508197,1143 | 18 | 1×2 / 5 in | 1 | N | B | none | N |
| 8 | CE | 958.508197,1143; 1030,1143 | 18 | 1×2 / 5 in | 1 | N | B | none | N |
| 9 | CE | 1030,1143; 1030,1180 | 18 | 1×2 / 5 in | 1 | N | B | none | N |

| Structure | Kind | x ft | y ft | Height ft | Guys | Dead end | Excavation |
|---|---|---:|---:|---:|---:|:---:|---|
| MH1 | MH | 695 | 1143 | – | – | – | box |
| MH2 | MH | 1030 | 1143 | – | – | – | box |

Dewater 8-ft manhole excavation(s): MH1.

| Pull | From | To | Plan ft | Max tension lb | SWBP lb/ft | Minimum D/d | Max fill % |
|---|---|---|---:|---:|---:|---:|---:|
| P1 | START | MH1 | 288.00 | 797.49 | 32.06 | 3.63 | 22.76 |
| P2 | MH1 | MH2 | 335.00 | 486.88 | 0.00 | 3.27 | 27.99 |
| P3 | END | MH2 | 37.00 | 233.69 | 32.06 | 3.79 | 20.93 |

**Rate references:** adjusted rates for every priced code are in Appendix A. The following table identifies all labor, equipment, and material line codes used per alternative; takeoff quantities and dollars are in the workbook.

| Type | Labor codes | Equipment IDs | Material/subcontract codes |
|---|---|---|---|
| CEDB | EX-MACH, BF-COMP, DUCT-CE, GND-DB, CONC-PL, TAPE, MH-SET, MH-BASE, TBOX, DEWATER, FIREPROOF, PULL-MV-L, TERM-MV | C10BO003, C80TE008, H25CA040, L50CA001, P50WC002, RQ-BDT, RQ-PUL, RQ-TBX | EX-MACH, BF-COMP, EB20-5, SPACER, GND-4/0, CONC-3000, TAPE, TAPE-DET, RGS-5, MH-SET, MH-PRECAST, MH-BASE, ROCK-BASE, TBOX, DEWATER, FIRETAPE, PULL-MV-L, CBL-250, TERM-KIT |
| UEDB | EX-MACH, BF-COMP, DUCT-UE, GND-DB, SAND-BED, TAPE, MH-SET, MH-BASE, TBOX, DEWATER, FIREPROOF, PULL-MV-L, TERM-MV | C10BO003, C80TE008, H25CA040, L50CA001, P50WC002, RQ-BDT, RQ-PUL, RQ-TBX | EX-MACH, BF-COMP, SCH40-5, SPACER, GND-4/0, SAND-BED, SAND, TAPE, TAPE-DET, RGS-5, MH-SET, MH-PRECAST, MH-BASE, ROCK-BASE, TBOX, DEWATER, FIRETAPE, PULL-MV-L, CBL-250, TERM-KIT |
| DBC | EX-TRCH, BF-COMP, SAND-BED, TAPE, EX-MACH, MH-SET, MH-BASE, TBOX, DEWATER, FIREPROOF, DBC-LAY, PULL-MV-L, TERM-MV | C10BO003, C80TE008, H25CA040, L50CA001, P50WC002, RQ-BDT, RQ-PUL, RQ-TBX, T30DW022 | EX-TRCH, BF-COMP, SAND-BED, SAND, TAPE, TAPE-DET, RGS-5, EX-MACH, MH-SET, MH-PRECAST, MH-BASE, ROCK-BASE, TBOX, DEWATER, FIRETAPE, DBC-LAY, PULL-MV-L, CBL-250, TERM-KIT |
| HDD | EX-MACH, BF-COMP, MH-SET, MH-BASE, TBOX, DEWATER, FIREPROOF, PULL-MV-L, TERM-MV | C10BO003, C80TE008, H25CA040, L50CA001, P50WC002, RQ-BDT, RQ-PUL, RQ-TBX | RGS-5, EX-MACH, BF-COMP, MH-SET, MH-PRECAST, MH-BASE, ROCK-BASE, TBOX, DEWATER, FIRETAPE, PULL-MV-L, CBL-250, TERM-KIT |
| OH | EX-MACH, BF-COMP, DUCT-CE, GND-DB, CONC-PL, TAPE, PULL-MV-L, TERM-MV, POLE-SET, POLE-HOLE, XARM, GUY, RISER, STRING | C10BO003, H25CA040, L50CA001, RQ-BDT, RQ-PUL | EX-MACH, BF-COMP, EB20-5, SPACER, GND-4/0, CONC-3000, TAPE, TAPE-DET, PULL-MV-L, CBL-250, TERM-KIT, POLE-SET, POLE-45, POLE-HOLE, XARM, XARM-ASSY, GUY, GUY-ASSY, POLE-50, RISER, RISER-ASSY, STRING, ACSR-1/0 |
## Appendix B: requirements register
The full applied requirements register, including clause-level criteria for route geometry, ampacity, overhead, trench protection, structures, and pull limits, is in the Register worksheet. The Findings worksheet records the SUE depth conflicts and the standard/UFC manhole-size conflict and states the values used.

## Verification notes
All alternatives have one row per item and required type. The workbook keeps only the two required live formula families: Alternative direct-to-cost-per-foot formulas reference Takeoff and Markups, and LaborRates loaded rates reference their row inputs. Each recommended route has ordered segments, route coordinates, structures, and cable pulls.

### Loaded craft wages

| class | wd_group | classification | base_usd | fringe_usd | burden_pct | loaded_rate_usd |
|---|---|---|---|---|---|---|
| LINEMAN | ELEC1245-001 | LINE CONSTRUCTION: (1) LINEMAN; CABLE SPLICER | 70.16 | 24.71 | 20.39 | 109.175624 |
| EQSPEC | ELEC1245-001 | LINE CONSTRUCTION: (2) EQUIPMENT SPECIALIST | 53.3 | 22.26 | 20.39 | 86.42787 |
| GROUNDMAN | ELEC1245-001 | LINE CONSTRUCTION: (3) GROUNDMAN | 40.76 | 21.76 | 20.39 | 70.830964 |
| ELECTRICIAN | ELEC0011-004 | ELECTRICIAN: INSIDE ELECTRICAL WORK: JOURNEYMAN ELECTRICIAN | 60.8 | 31.59 | 15.77 | 101.97816 |
| SPLICER_IN | ELEC0011-004 | ELECTRICIAN: INSIDE ELECTRICAL WORK: CABLE SPLICER (5% ADDITIONAL) | 63.84 | 31.59 | 15.77 | 105.497568 |
| LAB1 | LABO0300-003 | LABORER GROUP 1 | 46.48 | 25.95 | 19 | 81.2612 |
| LAB3 | LABO0300-003 | LABORER GROUP 3 | 47.58 | 25.95 | 19 | 82.5702 |
| LAB4 | LABO0300-003 | LABORER GROUP 4 (PREFABRICATED MANHOLE INSTALLER) | 49.13 | 25.95 | 19 | 84.4147 |
| PUMPOP | ENGI0012-024 | OPERATOR: POWER EQUIPMENT, ALL OTHER WORK: GROUP 1 (PUMP OPERATOR) | 63.4 | 33.2 | 19 | 108.646 |

### Equipment operating rates

| equipment_id | description | source | hourly_rate_usd |
|---|---|---|---|
| H25CA040 | HYDRAULIC EXCAVATOR, CRAWLER, 40,600 LBS, 1.00 CY BUCKET, 22.50' MAX DIGGING DEPTH | EP 1110-1-8 Vol. 7 (2016), Table 2-1/App. F; §§3.9–3.10 + FSI-0826-2207 | 58.676991 |
| T30DW022 | TRENCHER, CHAIN TYPE CUTTER, 48" MAX DEPTH X 3.5"-6" WIDTH, WALK BEHIND, CRAWLER | EP 1110-1-8 Vol. 7 (2016), Table 2-1/App. F; §§3.9–3.10 + FSI-0826-2207 | 14.61012 |
| L50CA001 | LOADER / BACKHOE, WHEEL, 1.00 CY FRONT END BUCKET, 24" DIP, 14.5' DIGGING DEPTH, 4X2 | EP 1110-1-8 Vol. 7 (2016), Table 2-1/App. F; §§3.9–3.10 + FSI-0826-2207 | 30.982035 |
| C10BO003 | COMPACTOR, VIBROPLATE, 14.2" X 22" PLATE, 2,250 LBS IMPACT | EP 1110-1-8 Vol. 7 (2016), Table 2-1/App. F; §§3.9–3.10 + FSI-0826-2207 | 2.900602 |
| C80TE008 | CRANES, HYDRAULIC, TRUCK MTD, ROUGH TERRAIN, 25 TON, 72' BOOM, 4X4 | EP 1110-1-8 Vol. 7 (2016), Table 2-1/App. F; §§3.9–3.10 + FSI-0826-2207 | 61.058407 |
| P50WC002 | PUMP, WATER, CENTRIFUGAL, TRASH, ENGINE DRIVE, 3" DIA, 425 GPM @ 95' HEAD | EP 1110-1-8 Vol. 7 (2016), Table 2-1/App. F; §§3.9–3.10 + FSI-0826-2207 | 3.852832 |
| RQ-PUL | Cable puller, hydraulic capstan/bullwheel, 10,000 lb with dynamometer | RQ-26-0419 | 58.5 |
| RQ-BDT | Bucket / digger-derrick line truck, 47 ft, 4x4 | RQ-26-0419 | 96 |
| RQ-TBX | Steel 8 ft x 20 ft trench shield | RQ-26-0419 | 7.25 |
| RQ-LFT | Scissor lift, 26 ft, electric (indoor) | RQ-26-0419 | 11.8 |

### Project markups

| parameter | value |
|---|---|
| jooh_pct | 9.5 |
| hooh_pct | 4.5 |
| profit_pct | 7.949418 |
| bond_rate_pct | 1.251348 |
| escalation_factor | 1.019388 |
| contingency_pct | 5 |
| sioh_pct | 5.7 |
| area_cost_factor_applied | 1 |
| wage_determination | CA20260022 Mod 5 |

### Government-furnished document findings

| finding_id | document | location | defect | correction |
|---|---|---|---|---|
| F01 | SUE-24-0117 | Table 1 TH-1/TH-2 | Record W-12 depth 72 in conflicts with QLA measured 56 in | Used SUE 56 in |
| F02 | SUE-24-0117 | Table 1 and QLB CSV | W-12 record OD 12 in conflicts with measured/CSV OD 12.75 in | Used 12.75 in OD and 56 in top depth |
| F03 | UFC 3-550-01 C3 §3-11.5.6 / IEDS 4.10 / RFP 3.7 | Manhole dimensions | UFC minimum interior 6.5 ft depth differs from IEDS standard 6x8x7 and RFP takeoff outside 7.33x9.33 | Designed to IEDS 6x8x7; priced RFP 7.33x9.33 outside |
| F04 | E-001 Rev B vs PDS Rev D | F1 phase pickup | One-line shows 560 A; current PDS Rev D shows 640 A | Used PDS Rev D 640 A per IEDS 1.3 |
