# Method of Procedure (MOP) - Cooling Water Flush, Chemical Clean and Passivation

## 1. Scope
This Method of Procedure covers the pre-operational flushing, chemical cleaning, rinsing, passivation, 14-21 day film-formation hold and turnover of eight closed chilled-water circuits C1-C8 (23 25 16). Turnover is by RETAIN_AND_TOP_UP for every circuit: the passivation charge is retained and topped up to the maintenance residual at turnover (23 25 16 cl.3.8). No circuit is drained and refilled.
This is an execution plan. Calculated quantities and scheduled activities are not evidence of completed field work; site readiness, training, samples and acceptance remain to be verified and recorded before the corresponding release.

## 2. Design basis
Initial-flush, chemical-cleaning and rinse flows meet or exceed the 23 25 16 cl.3.3 velocity floor at the governing segment (4.00 ft/s plate heat-exchanger and cold-plate circuits, 3.28 ft/s otherwise; UFC 3-230-13 suspension velocity 3.28 ft/s). Heads are lift plus main-path loss plus in-path component drops plus per-skid hose and strainer drops (23 25 16 cl.3.2). Rinse displacements follow the mixing model of 23 25 16 cl.3.6 (eta 0.62, 0.45 cold-plate/coil bank) to the 10% conductivity endpoint. The governing constraint for each circuit (23 25 16 cl.1.6) is stated below.
GOVERNING CONSTRAINT C1: H14_water_budget (margin 0.0007)
GOVERNING CONSTRAINT C2: H14_water_budget (margin 0.0007)
GOVERNING CONSTRAINT C3: H14_water_budget (margin 0.0007)
GOVERNING CONSTRAINT C4: H14_water_budget (margin 0.0007)
GOVERNING CONSTRAINT C5: H14_water_budget (margin 0.0007)
GOVERNING CONSTRAINT C6: H14_water_budget (margin 0.0007)
GOVERNING CONSTRAINT C7: H14_water_budget (margin 0.0007)
GOVERNING CONSTRAINT C8: H14_water_budget (margin 0.0007)
Document conflicts and defects resolved for this plan (23 25 16 cl.1.6): use UFC 3-230-13 dated 1 March 2023; the cancelled 2005 UFC 3-240-13FN is not a basis. Use the current Rev C mechanical drawings and schedules; the superseded Rev A geometry is not a basis. SW-03 Rev B authorises 500,000 gal, superseding the 540,000 gal cited in RFI-031. SI-04 reduces metered water to 31,000 gal on days 2 and 3 and zero on day 6; trucked water remains limited to 30,000 gal/day. SI-05 delays FS-1200-A until hour 48. CX-02 entries without their cited pressure charts are not accepted under 01 91 13 cl.1.3; the affected circuits are tested as listed in Section 5. RFI-022 confirms the C8 galvanized metallurgy. The programme selection paragraph controls over the selection table as described in Section 3; the current passivation tables control film formation.

## 3. Programme and chemistry
Polysilicate-azole (UFC 3-230-13 cl.6-2.2.5) is selected on C1-C8: maintenance 80-100 ppm SiO2, target 85 ppm, controlled at pH 7.5-8.5 within the permitted 7.5-8.9 band. Under 23 25 16 cl.3.5 the programme paragraph governs selection; its benefit for aluminium does not restrict it to aluminium circuits. No nitrite is used: makeup (Cl+SO4) 860 mg/L exceeds the 800 mg/L limit of cl.6-2.2.2. Passivation (Table 5-15) is polysilicate 40-50 ppm SiO2, target 42.5 ppm, pH 7.5-8.5, held 14-21 days as scheduled for film formation. Copper-bearing circuits carry tolyltriazole 10 ppm. Cleaning is CL-100 alkaline (C1-C5, C7) or CL-210 neutral (C6, C8, galvanized and aluminium) with polyacrylate dispersant 5 ppm, circulated 24 h. All doses are referred to the circuit system volume.

## 4. Water, softening and discharge
Makeup hardness is 288 mg/L, above the 250 mg/L closed-system limit (UFC 3-230-13 Table 6-1). Turnover makeup uses a partially softened split-stream blend: 20% is drawn through SV-2, with the remainder raw, per UFC 6-2.1 and 3-2.1. The blend hardness is 0.20 x 20 + 0.80 x 288 = 234.4 mg/L, below 250 mg/L. Meter both streams and verify hardness before filling. SF-1 has 88,000 grains between daily regenerations; only the softened share is booked against its capacity. Discharge to the metered sewer (SW-03 Rev B, 500,000 gal programme total) is allowed only where the stream meets the local limits (pH 6.0-9.0, temperature 104 degF, Mo 0.5, Zn 1.0, Cu 1.0 mg/L). Spent cleaning solution from copper-pipe circuits carries 3.4 mg/L total copper (CL-100) or 1.6 mg/L (CL-210) and from the galvanized circuit 5.5 mg/L total zinc, all above the 1.0 mg/L local limits, so the chemical cleaning and rinse effluent of C4-C8 is hauled off site by vacuum tanker at $168.00/1000 gal. Cascade transfers (C4 to C2, C5 to C3, C8 to C6, C6 to C7) donate one receiver displacement of rinse water and reduce fresh draw and donor discharge by the same volume; the donor discharge route determines the disposal saving.

## 5. Hydrostatic testing
Provide two independent hydrostatic test setups, one per attending crew, each with its own rated pump, isolation and calibrated pressure gauge. Provide a portable cascade holding tank and required fine filtration within mobilisation (23 25 16 cl.3.10 f); these are excluded from the priced comparison. The flush skids are not test pumps.
Circuits C1, C2, C4 and C8 are recorded as tested and accepted in CX-02 and are not retested. Circuits C3, C5, C6 and C7 have no accepted hydrostatic test on record (their CX-02 entries cite a pressure chart that is not on file, 01 91 13 cl.1.3), so each is hydrostatically tested at 130 psig (above 1.5x the 85 psig operating pressure, minimum 125 psig, within the 150 psig lowest component rating) with a 120-minute hold, finishing before chemical cleaning starts. Bypass spools are fitted after the hydrostatic test and removed at turnover TM-4; the remade joints are leak-checked at turnover. The temporary strainer is 40-mesh (380 micron). At turnover the fill passes through 50-micron fine filtration for the cold plates (CP-311, CP-321, CP-331), whose M-602 maximum particle size is 50 micron.

## 6. Safety and Hazard Communication (29 CFR 1910.1200)
Before handling chemicals, provide safety data sheets (SDS) on site and accessible to every crew member - 29 CFR 1910.1200(g). Label all containers with the product identifier and hazard warnings - 29 CFR 1910.1200(f). Keep this written hazard communication program on site - 29 CFR 1910.1200(e). Give and record information and training for every crew member before chemical handling - 29 CFR 1910.1200(h). Release chemical work only after these provisions have been verified.
Provide the VD-07 SDS for the selected products: CL-100, CL-210, PD-45, PS-330, TA-90. CL-100 alkaline cleaner (pH 10.4) and CL-210 neutral cleaner (pH 8.2) are corrosive to skin and eyes; PS-330 polysilicate is an irritant. Follow VD-07 Sections 4 and 8 for every selected product: provide eyewash and a quick-drench shower within 10 seconds of each chemical handling point. When transferring chemicals, wear chemical splash goggles, a face shield, chemical-resistant gloves and an apron. Contain and absorb spills and dispose of residues as chemical waste. Keep neat chemical and spill residues contained. Process effluent follows Section 4.

## 7. Schedule and turnover
Two commissioning crews (CREW-1, CREW-2) attend the work; no crew attends two activities at once and no skid serves two circuits at once. FS-1200-A is on site from hour 48 (SI-05, VD-02 delivery delayed 2 days) and is not booked before then. All circuits complete turnover by TM-4, day 47 (hour 1128).
Maintain the CX-03 log under 23 25 16 cl.1.5 for each circuit: record measured minimum velocity and governing segment; strainer mesh and removal; occupied cleaning time; rinse clarity, suspended solids, conductivity and pH against makeup; passivation residual, pH and film-formation hold; discharge volume, route, pH and temperature; and turnover residual and bacteria count. Record actual observations against acceptance_matrix.csv before accepting each gate. Do not substitute the model predictions for field measurements.
C1: turnover (FINAL_FILL) hour 532.3-532.8 (day 22.2); skid FS-600-A; programme polysilicate-azole.
C2: turnover (FINAL_FILL) hour 531.7-532.3 (day 22.2); skid FS-600-A; programme polysilicate-azole.
C3: turnover (FINAL_FILL) hour 531.0-531.7 (day 22.2); skid FS-600-A; programme polysilicate-azole.
C4: turnover (FINAL_FILL) hour 529.7-530.4 (day 22.1); skid FS-600-A; programme polysilicate-azole.
C5: turnover (FINAL_FILL) hour 528.0-528.6 (day 22.0); skid FS-600-A; programme polysilicate-azole.
C6: turnover (FINAL_FILL) hour 529.1-529.7 (day 22.1); skid FS-600-A; programme polysilicate-azole.
C7: turnover (FINAL_FILL) hour 530.4-531.0 (day 22.1); skid FS-600-A; programme polysilicate-azole.
C8: turnover (FINAL_FILL) hour 528.6-529.1 (day 22.0); skid FS-600-A; programme polysilicate-azole.

