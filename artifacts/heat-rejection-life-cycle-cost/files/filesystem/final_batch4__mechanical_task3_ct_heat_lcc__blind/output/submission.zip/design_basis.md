# Design Basis — Condenser Water Heat Rejection Replacement
Papago Federal Center, Phoenix, Arizona (95% Construction Documents)

## Governing documents

- DC-02 Mechanical Design Criteria Memorandum, Revision 3 (14 August 2026) — governs the design criteria, deliverables and design basis content.
- UFC 3-410-01, HVAC Systems (28 July 2025, Change 1) — adopted in full; governs outdoor design conditions for equipment sizing.
- GSA PBS-P100 Facilities Standards (2024) — adopted as the agency facilities standard; governs plant configuration, redundancy, siting separations, materials and roof-mounted equipment.
- UFM 3-230-13, Industrial Water Treatment (5 February 2026) — adopted for the condenser water treatment programme, water balance and scaling indices.
- 10 CFR Part 431 Subpart B (electric motors) and 10 CFR Part 436 Subpart A (life-cycle cost analyses).
- EC-01 Life-Cycle Cost Analysis Criteria, Revision 0, and the NIST Annual Supplement 2025 edition (NISTIR 85-3273-40) for the discount rate and present-value factors.
- EnergyPlus reference implementation source and performance data sets (CoolingTowerPerformance:YorkCalc, ChillerElectricEIR, Psychrometrics) — adopted as the simulation basis.

## Weather basis

The climatic basis is the NCEI Local Climatological Data record of Phoenix Airport station 72278023183 for the three complete calendar years in the library, FM-15/FM-16 observations only. The design outdoor wet bulb is the 1.0 percent annual wet bulb of that period of record, 75.0 deg F, plus the 5 deg F adder that UFC 3-410-01 paragraph 2-4.2.4 requires for open cooling towers, giving a design wet bulb of 80.0 deg F. The failure-case (redundancy) wet bulb is 81.0 deg F, the basis the agency facilities standard prescribes for evaporative machines. The 99.6 percent annual dry bulb computed from the period of record is 41.0 deg F, which is above the 32 deg F threshold of DC-02 paragraph 5.4, so no basin heater and no heat-traced makeup piping are provided; the basin heater determination is NO on all three plants.

## Evaporation formulation

The evaporation formulation used throughout this package is saturated-exit, the moist-air method of the reference implementation's tower water-use routine. The water balance of every workbook is computed consistently with saturated-exit. The loss-factor rule of thumb of UFM 3-230-13 paragraph 5.2.1.3 was not used.

## Method

- Design point: the YorkCalc variable-speed tower approach correlation at full fan speed, with the chiller EIR capacity and power curves, iterated to convergence on the entering condenser water temperature. The workbook reports the achieved range, approach and supply temperature, not the scheduled target.
- Off-design: 180 scenario bins from the period of record (2 deg F wet-bulb bins, 5 deg F dry-bulb bins, scaled to 8760 hours per year), simulated with the reference implementation's staging rules — chillers stage on in order, condenser pumps run at the scheduled per-chiller flow, cells stage per DC-02 paragraph 6.6, fans modulate to the wet-bulb-following reset setpoint (floor plus offset, capped at the design supply temperature).
- Water balance: saturated-exit evaporation, drift at the certified DE-2 rate scaled by the reported air flow ratio, blowdown by UFM Equation 5-4 from evaporation and cycles of concentration.
- Life-cycle cost: 10 CFR 436 Subpart A as EC-01 directs — real discount rate 3 percent, study period 26 years including 1 year construction, UPV* factors from the NIST 2025 supplement, water priced on the saturated-exit simulation basis.
- Cycles of concentration are set at the Puckorius scaling index limit (PSI floor 5.6 at the design condenser water return temperature), which governs over the silica limit (150 ppm) on all three plants.

## Plant designs

- CUP: 4 cells CTX-0600-S, 1800 gpm total (450 gpm/cell), design CWS 86.0 deg F, setpoint floor 65.5 deg F, offset 11.5 deg F, COC 4.14, SS-304, DE-2 drift eliminator, 20 hp TEFC premium motors (91.7%).
- ANNEX: 4 cells CTX-0600-S, 1800 gpm total (450 gpm/cell), design CWS 86.5 deg F, setpoint floor 79.5 deg F, offset 11.5 deg F, COC 4.0, SS-304, DE-2, 20 hp TEFC premium motors (91.7%).
- LAB: 3 cells CTX-0900-H, 2025 gpm total (675 gpm/cell), design CWS 86.5 deg F, setpoint floor 57.4 deg F, offset 8.875 deg F, COC 3.88, SS-304, DE-2, 20 hp TEFC premium motors (91.7%).

Cell counts are whole multiples of the chillers served (4 for 2, 4 for 2, 3 for 3). All cells of a plant are identical. Equalising lines and automatic isolation are provided; automatic blowdown and chemical feed are provided. Basin clearance is 4.0 ft on all plants.

## Governing constraints

GOVERNING CONSTRAINT CUP: electrical capacity (relative margin 0.0245)
GOVERNING CONSTRAINT ANNEX: water allocation (relative margin 0.0001)
GOVERNING CONSTRAINT LAB: electrical capacity (relative margin 0.0102)

CUP is governed by the MCC-R1 spare capacity (peak coincident demand 515.1 kW against 528.0 kW spare); the structural margin (0.0250) is within 0.004 of it. ANNEX is governed by the reclaimed water allocation (annual makeup 12598.3 kgal against the amended 12600 kgal allocation). LAB is governed by the MCC-R3 spare capacity (peak coincident demand 634.6 kW against 641.1 kW spare).

## Documented conflicts

CONFLICT 1: ADOPTED UFC 3-410-01 paragraph 2-4.2.4 | SET ASIDE GSA PBS-P100 paragraph 5.3.1
CONFLICT 2: ADOPTED UFM 3-230-13 2026 edition | SET ASIDE UFC 3-230-13 2023 edition
CONFLICT 3: ADOPTED M-401 Rev C | SET ASIDE M-401 Rev B

Conflict 1: the outdoor design condition for cooling tower selection is governed by UFC 3-410-01 paragraph 2-4.2.4 (1.0 percent wet bulb plus the 5 deg F open-tower adder); the facilities standard's dew-point basis does not govern tower selection. Conflict 2: the industrial water treatment edition is governed by UFM 3-230-13 (2026); UFC 3-230-13 (2023) is superseded and retained for reference only. Conflict 3: the roof mechanical plan is governed by M-401 Rev C; Rev B is superseded.

## Margins and judgement calls

- The ANNEX water allocation margin (0.0001) is essentially zero by design: the reference search set the cycles of concentration at the scaling-index limit, and the annual makeup lands 1.7 kgal inside the amended allocation. Any increase in cycles would breach the PSI floor; any decrease would breach the allocation.
- The CUP and LAB electrical margins (0.0245 and 0.0102) are the binding limits on fan and chiller demand; the designs sit just inside the MCC spare capacities.
- Design supply temperatures are scheduled conservatively (warmer than the cells achieve): CUP achieves 85.36 deg F against 86.0 scheduled, ANNEX 85.69 against 86.5, LAB 85.99 against 86.5.
- All three plants carry N+1 redundancy: with the largest cell out of service at the 81.0 deg F failure wet bulb, the remaining cells carry the design block load (CUP 905 tons, ANNEX 933 tons, LAB 1207 tons available).
- The 99.6 percent dry bulb is 41.0 deg F, so no basin heater is provided; freeze protection is not a governing constraint on any plant.
