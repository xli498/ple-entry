# Design Basis
Governing documents are DC-02 Mechanical Design Criteria Memorandum Rev3, EC-01 Rev0, UFC 3-410-01 Change 1, GSA PBS-P100 2024, UFM 3-230-13 2026, WT-01 Rev1, PW-LTR-014 as amended by PW-LTR-019, current M-401/S-401 RevC, E-601 RevC, reviewed VD-01 through VD-05, and UT-01. Superseded/cancelled editions are reference only.

CONFLICT 1: ADOPTED UFC 3-410-01 paragraph 5.2 and DC-02 paragraph 5.2 | SET ASIDE GSA PBS-P100 paragraph 5.1.3
CONFLICT 2: ADOPTED UFM 3-230-13 paragraph 1 and WT-01 paragraph 4 | SET ASIDE UFC 3-230-13 paragraph 1
CONFLICT 3: ADOPTED M-401 Revision C general notes and DC-02 paragraph 2 | SET ASIDE M-401 Revision B superseded revision

The selected cell is CTX-0900-H for CUP/ANNEX (four cells, 2,100 gpm total, 525 gpm per cell) and CTX-1350-H for LAB (three cells, 2,130 gpm total, 710 gpm per cell). Each plant has a whole-multiple cell count so one cell can be isolated while dedicated chiller pumps continue. DE-3, SS-304, premium TEFC 20 hp motors and VFDs are scheduled. The frame rectangles are in the M-401 coordinate system and are within the equipment/framing zones with 6 ft inlet separation and 4 ft basin clearance. The saturated-exit formulation is used consistently in the scenario water balance. COC is 4.00 and the reported PSI is 5.90 at design CWR.

The annual scenario table uses the adopted three-year Phoenix airport FM-15/FM-16 record, 2 F wet-bulb and 5 F dry-bulb bins scaled to 8,760 hours. Chiller staging follows DC-02 6.5; cell staging follows 6.6. Pump input follows the fixed-head equation in 6.4. The design report uses a 25 F conservative range and wet-bulb-following reset; design-point reporting is the selected equipment result. Life-cycle values use EC-01, 2025 NIST DOE/FEMP factors, UT-01, PW-LTR-014 and VD-05.

Computed 99.6 percent dry bulb is 114.0 F, above 32 F, so basin heaters and heat-traced makeup are not required.
GOVERNING CONSTRAINT CUP: condenser flow limit (relative margin 0.167)
GOVERNING CONSTRAINT ANNEX: condenser flow limit (relative margin 0.167)
GOVERNING CONSTRAINT LAB: condenser flow limit (relative margin 0.334)
