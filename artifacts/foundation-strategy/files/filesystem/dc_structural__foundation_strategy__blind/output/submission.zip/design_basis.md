```json
{
  "frost": {
    "afi_100yr_F_days": 556,
    "afi_product_period": "1981-2010 normals, current NCEI return-period product",
    "frost_depth_in": 42,
    "superseded_product_period": "1951-1980",
    "superseded_afi_100yr_F_days": 416
  },
  "pads": {
    "CR-P1": {
      "governing_constraint": "SETTLEMENT",
      "foundation_decision": "IMPROVED_SPREAD",
      "spread_only_cost_usd": 243155.24585811637,
      "improved_cost_usd": 89200.53568325797
    },
    "CR-P2": {
      "governing_constraint": "SETTLEMENT",
      "foundation_decision": "IMPROVED_SPREAD",
      "spread_only_cost_usd": 266792.0903566209,
      "improved_cost_usd": 96269.85290159278
    },
    "CR-P3": {
      "governing_constraint": "SETTLEMENT",
      "foundation_decision": "IMPROVED_SPREAD",
      "spread_only_cost_usd": 33504.367540494335,
      "improved_cost_usd": 57388.54544657506
    },
    "CR-P4": {
      "governing_constraint": "SETTLEMENT",
      "foundation_decision": "IMPROVED_SPREAD",
      "spread_only_cost_usd": 57690.78284917118,
      "improved_cost_usd": 48995.13476301401
    },
    "CR-P5": {
      "governing_constraint": "SETTLEMENT",
      "foundation_decision": "IMPROVED_SPREAD",
      "spread_only_cost_usd": 18390.813470681147,
      "improved_cost_usd": 36763.64680401448
    },
    "CR-P6": {
      "governing_constraint": "SETTLEMENT",
      "foundation_decision": "IMPROVED_SPREAD",
      "spread_only_cost_usd": 213000.38673399834,
      "improved_cost_usd": 91043.17646709838
    }
  },
  "campus": {
    "rigs_mobilised": 3,
    "mobilisation_cost_usd": 120000.0,
    "total_cost_usd": 539660.89,
    "pads_improved": [
      "CR-P1",
      "CR-P2",
      "CR-P3",
      "CR-P4",
      "CR-P5",
      "CR-P6"
    ]
  },
  "rejected_criteria": [
    "presumptive 3,000 psf preliminary value",
    "cancelled UFC 3-220-01N and UFC 3-220-10N",
    "superseded Rev1 and Geotechnical Addendum 1",
    "adjacent Broadview Commons report",
    "1951-1980 AFI product",
    "deep foundations not accepted for Phase 1"
  ]
}
```

# Design Basis

## Governing documents and conflicts
The governing package is UFC 3-220-01 (2012, Change 3), UFC 3-301-01 (2023, Change 4), UFGS 03 30 00, the Rev. 2 geotechnical data report, the civil groundwater record, the structural reaction export and load-combination memorandum, Rev. 3 of the structural Basis of Design, and the AHJ letter LC-BD-26-0774. Rev. 1 of the Basis of Design and Geotechnical Addendum 1 are superseded; the adjacent-parcel report is information only; cancelled UFC 3-220-01N and UFC 3-220-10N are set aside. The older NOAA 1951-1980 AFI product is superseded by the current 1981-2010 product. The conflict is resolved in favor of the later/current document: AFI is 556 F-days and the AHJ frost depth is 42 in.

The report's 3,000 psf value is expressly preliminary and the AHJ prohibits presumptive values. I used site-specific drained bearing capacity by Terzaghi, Meyerhof and Brinch Hansen, using the governing UFC 3-220-20 Eq. 5-15 family and groundwater-corrected effective unit weights, and reported the least allowable net capacity after the occupancy-specific UFC Table 2-3 FS. Bearing and settlement use D+L service reactions; strength reactions use 1.2D+1.6L.

## Movement and stability
Layered elastic compression follows RFI-019: 2:1 rectangular stress distribution, uniform 0.25-ft layers, through 4B and at least 40 ft, with the Rev. 2 pad-specific Es values. Improved settlement is FHWA GEC13 Eq. 5-11: upper-zone qg/kg plus the same lower-zone elastic calculation. The tolerable total movement is the lesser of the UFC 1.0 in limit and the project/building movement criterion; I adopted 1.0 in and angular distortion no greater than 1/500. The less stringent bridge/simple-span 0.005 criterion was rejected. Wall footings satisfy the memorandum's middle-third resultant, sliding FS 2.0, and 0.6-weight uplift method.

## Concrete and ground improvement
Exposure is F1/W1/C1 for P1-P4 and P6 and F3/W1/C1 for P5. Measured Stratum I sulfate selects S0 for P3/P5, S1 for P1/P4, and S2 for P2/P6; UFGS Table 2-2 and exposure tables set the w/cm and f'c values. Footing dimensions and thickness are on the 3-in grid, widths meet the 24-in column and 18-in continuous-footing rules, and thickness is never below 12 in. Grade 60 reinforcement uses the project 0.0018 ratio and the UFC thick-footing provision where applicable.

FHWA GEC13 Section 4.2.1 permits stress ratio 10 for rigid structure footings; Eq. 5-12 gives top-of-pier stress, Eq. 5-13 gives upper-zone movement, and the proposal supplies the 30-in diameter, 8-ft minimum/25-ft maximum treatment depth, tested pad-specific modulus, and 18,000 psf top stress limit. Every footing meets the 0.33 replacement ratio. One production modulus test is assigned to each improved pad.

## Programme and optimisation
The compliant least-cost pad alternatives are compared in the matrix. Each pad is improved because the spread-only alternative either fails the 1-in movement requirement or is more expensive than the compliant improved alternative under the issued prices. All six pads therefore require improvement. Kettleridge limits one mobilised rig to two pads, so three rigs is the minimum and costs $120,000; the assignments are P1/P2, P3/P4 and P5/P6. The campus total in the opening JSON is the sum of the selected pad work and this minimum mobilisation cost.
