# Foundation Feasibility and Optimisation Matrix

Units: demand and allowable pressure are ksf; settlement is in; costs are USD. All improved choices use ns=10, 30-in piers.

## CR-P1
Pad decision: **IMPROVED_SPREAD**; governing constraint: **SETTLEMENT**. Spread-only alternative cost $243,155; improved alternative cost $89,201. Bearing FS = 3.5; depth = 48 in; settlement limit = 1.00 in; angular distortion limit = 1/500.

|Foundation|Type|Demand|Allowable|Settlement|Bearing stratum|Pier check|Stability (W1)|Constraint|Spread vs improved cost|
|---|---|---:|---:|---:|---|---|---|---|---:|
|F1|IMPROVED_SPREAD|4.820|5.023|0.604|I|n=9, qg=11637 psf, ratio=0.349, depth=8 ft|n/a|SETTLEMENT|$243,155 / $89,201|
|F2|IMPROVED_SPREAD|5.074|5.214|0.719|I|n=16, qg=12561 psf, ratio=0.338, depth=8 ft|n/a|SETTLEMENT|$243,155 / $89,201|
|F3|IMPROVED_SPREAD|5.061|5.245|0.757|I|n=19, qg=12679 psf, ratio=0.332, depth=8 ft|n/a|SETTLEMENT|$243,155 / $89,201|
|F4|IMPROVED_SPREAD|5.000|5.193|0.687|I|n=14, qg=12032 psf, ratio=0.351, depth=8 ft|n/a|SETTLEMENT|$243,155 / $89,201|
|F5|IMPROVED_SPREAD|4.717|4.971|0.578|I|n=8, qg=11215 psf, ratio=0.356, depth=9 ft|n/a|SETTLEMENT|$243,155 / $89,201|
|W1|IMPROVED_SPREAD|4.661|4.793|0.692|I|n=25, qg=11313 psf, ratio=0.347, depth=9 ft|FS sliding 3.22; e 7.4 in; FS uplift 3.18|SETTLEMENT|$243,155 / $89,201|

Bearing used the least of Terzaghi, Meyerhof and Hansen drained site-specific results with groundwater-corrected unit weights. The strength combination checked footing shear/flexure; reported reinforcement is the larger of flexural demand and minimum ratios.
## CR-P2
Pad decision: **IMPROVED_SPREAD**; governing constraint: **SETTLEMENT**. Spread-only alternative cost $266,792; improved alternative cost $96,270. Bearing FS = 3.5; depth = 48 in; settlement limit = 1.00 in; angular distortion limit = 1/500.

|Foundation|Type|Demand|Allowable|Settlement|Bearing stratum|Pier check|Stability (W1)|Constraint|Spread vs improved cost|
|---|---|---:|---:|---:|---|---|---|---|---:|
|F1|IMPROVED_SPREAD|4.889|5.119|0.725|I|n=9, qg=12203 psf, ratio=0.334, depth=10 ft|n/a|SETTLEMENT|$266,792 / $96,270|
|F2|IMPROVED_SPREAD|5.042|5.266|0.822|I|n=17, qg=12519 psf, ratio=0.336, depth=9 ft|n/a|SETTLEMENT|$266,792 / $96,270|
|F3|IMPROVED_SPREAD|5.058|5.299|0.849|I|n=21, qg=12284 psf, ratio=0.346, depth=8 ft|n/a|SETTLEMENT|$266,792 / $96,270|
|F4|IMPROVED_SPREAD|5.116|5.239|0.814|I|n=14, qg=12644 psf, ratio=0.338, depth=8 ft|n/a|SETTLEMENT|$266,792 / $96,270|
|F5|IMPROVED_SPREAD|4.770|5.067|0.700|I|n=8, qg=11753 psf, ratio=0.340, depth=8 ft|n/a|SETTLEMENT|$266,792 / $96,270|
|W1|IMPROVED_SPREAD|4.779|4.883|0.819|I|n=25, qg=11894 psf, ratio=0.335, depth=8 ft|FS sliding 3.19; e 7.4 in; FS uplift 3.17|SETTLEMENT|$266,792 / $96,270|

Bearing used the least of Terzaghi, Meyerhof and Hansen drained site-specific results with groundwater-corrected unit weights. The strength combination checked footing shear/flexure; reported reinforcement is the larger of flexural demand and minimum ratios.
## CR-P3
Pad decision: **IMPROVED_SPREAD**; governing constraint: **SETTLEMENT**. Spread-only alternative cost $33,504; improved alternative cost $57,389. Bearing FS = 3.5; depth = 48 in; settlement limit = 1.00 in; angular distortion limit = 1/500.

|Foundation|Type|Demand|Allowable|Settlement|Bearing stratum|Pier check|Stability (W1)|Constraint|Spread vs improved cost|
|---|---|---:|---:|---:|---|---|---|---|---:|
|F1|IMPROVED_SPREAD|5.133|5.295|0.502|I|n=6, qg=12526 psf, ratio=0.344, depth=8 ft|n/a|SETTLEMENT|$33,504 / $57,389|
|F2|IMPROVED_SPREAD|5.437|5.535|0.580|I|n=11, qg=13229 psf, ratio=0.346, depth=8 ft|n/a|SETTLEMENT|$33,504 / $57,389|
|F3|IMPROVED_SPREAD|5.408|5.603|0.606|I|n=13, qg=13393 psf, ratio=0.338, depth=8 ft|n/a|SETTLEMENT|$33,504 / $57,389|
|F4|IMPROVED_SPREAD|5.335|5.485|0.567|I|n=9, qg=13317 psf, ratio=0.334, depth=8 ft|n/a|SETTLEMENT|$33,504 / $57,389|
|F5|IMPROVED_SPREAD|4.890|5.221|0.444|I|n=6, qg=10959 psf, ratio=0.385, depth=8 ft|n/a|SETTLEMENT|$33,504 / $57,389|
|W1|IMPROVED_SPREAD|4.714|4.862|0.540|I|n=17, qg=11844 psf, ratio=0.331, depth=8 ft|FS sliding 3.23; e 7.0 in; FS uplift 3.16|SETTLEMENT|$33,504 / $57,389|

Bearing used the least of Terzaghi, Meyerhof and Hansen drained site-specific results with groundwater-corrected unit weights. The strength combination checked footing shear/flexure; reported reinforcement is the larger of flexural demand and minimum ratios.
## CR-P4
Pad decision: **IMPROVED_SPREAD**; governing constraint: **SETTLEMENT**. Spread-only alternative cost $57,691; improved alternative cost $48,995. Bearing FS = 3; depth = 42 in; settlement limit = 1.00 in; angular distortion limit = 1/500.

|Foundation|Type|Demand|Allowable|Settlement|Bearing stratum|Pier check|Stability (W1)|Constraint|Spread vs improved cost|
|---|---|---:|---:|---:|---|---|---|---|---:|
|F1|IMPROVED_SPREAD|5.019|5.565|0.485|I|n=6, qg=11249 psf, ratio=0.385, depth=8 ft|n/a|SETTLEMENT|$57,691 / $48,995|
|F2|IMPROVED_SPREAD|5.621|5.767|0.639|I|n=9, qg=14030 psf, ratio=0.334, depth=8 ft|n/a|SETTLEMENT|$57,691 / $48,995|
|F3|IMPROVED_SPREAD|5.503|5.787|0.652|I|n=11, qg=13794 psf, ratio=0.332, depth=8 ft|n/a|SETTLEMENT|$57,691 / $48,995|
|F4|IMPROVED_SPREAD|5.600|5.707|0.602|I|n=8, qg=13315 psf, ratio=0.356, depth=8 ft|n/a|SETTLEMENT|$57,691 / $48,995|
|F5|IMPROVED_SPREAD|4.279|5.565|0.420|I|n=6, qg=9589 psf, ratio=0.385, depth=8 ft|n/a|SETTLEMENT|$57,691 / $48,995|
|W1|IMPROVED_SPREAD|4.812|4.924|0.533|I|n=17, qg=10749 psf, ratio=0.386, depth=8 ft|FS sliding 3.10; e 6.9 in; FS uplift 3.09|SETTLEMENT|$57,691 / $48,995|

Bearing used the least of Terzaghi, Meyerhof and Hansen drained site-specific results with groundwater-corrected unit weights. The strength combination checked footing shear/flexure; reported reinforcement is the larger of flexural demand and minimum ratios.
## CR-P5
Pad decision: **IMPROVED_SPREAD**; governing constraint: **SETTLEMENT**. Spread-only alternative cost $18,391; improved alternative cost $36,764. Bearing FS = 2.5; depth = 45 in; settlement limit = 1.00 in; angular distortion limit = 1/500.

|Foundation|Type|Demand|Allowable|Settlement|Bearing stratum|Pier check|Stability (W1)|Constraint|Spread vs improved cost|
|---|---|---:|---:|---:|---|---|---|---|---:|
|F1|IMPROVED_SPREAD|6.847|6.999|0.530|I|n=4, qg=14864 psf, ratio=0.401, depth=8 ft|n/a|SETTLEMENT|$18,391 / $36,764|
|F2|IMPROVED_SPREAD|7.191|7.518|0.616|I|n=7, qg=16245 psf, ratio=0.381, depth=8 ft|n/a|SETTLEMENT|$18,391 / $36,764|
|F3|IMPROVED_SPREAD|7.434|7.561|0.659|I|n=8, qg=17034 psf, ratio=0.374, depth=8 ft|n/a|SETTLEMENT|$18,391 / $36,764|
|F4|IMPROVED_SPREAD|7.040|7.363|0.589|I|n=6, qg=15777 psf, ratio=0.385, depth=8 ft|n/a|SETTLEMENT|$18,391 / $36,764|
|F5|IMPROVED_SPREAD|6.769|6.895|0.568|I|n=3, qg=16363 psf, ratio=0.349, depth=8 ft|n/a|SETTLEMENT|$18,391 / $36,764|
|W1|IMPROVED_SPREAD|6.050|6.131|0.561|I|n=11, qg=14270 psf, ratio=0.360, depth=8 ft|FS sliding 3.05; e 6.9 in; FS uplift 3.03|SETTLEMENT|$18,391 / $36,764|

Bearing used the least of Terzaghi, Meyerhof and Hansen drained site-specific results with groundwater-corrected unit weights. The strength combination checked footing shear/flexure; reported reinforcement is the larger of flexural demand and minimum ratios.
## CR-P6
Pad decision: **IMPROVED_SPREAD**; governing constraint: **SETTLEMENT**. Spread-only alternative cost $213,000; improved alternative cost $91,043. Bearing FS = 3.5; depth = 45 in; settlement limit = 1.00 in; angular distortion limit = 1/500.

|Foundation|Type|Demand|Allowable|Settlement|Bearing stratum|Pier check|Stability (W1)|Constraint|Spread vs improved cost|
|---|---|---:|---:|---:|---|---|---|---|---:|
|F1|IMPROVED_SPREAD|4.916|4.994|0.638|I|n=9, qg=11870 psf, ratio=0.349, depth=11 ft|n/a|SETTLEMENT|$213,000 / $91,043|
|F2|IMPROVED_SPREAD|5.010|5.108|0.756|I|n=17, qg=12142 psf, ratio=0.347, depth=8 ft|n/a|SETTLEMENT|$213,000 / $91,043|
|F3|IMPROVED_SPREAD|5.012|5.142|0.781|I|n=20, qg=12352 psf, ratio=0.340, depth=8 ft|n/a|SETTLEMENT|$213,000 / $91,043|
|F4|IMPROVED_SPREAD|4.923|5.083|0.717|I|n=14, qg=12167 psf, ratio=0.338, depth=8 ft|n/a|SETTLEMENT|$213,000 / $91,043|
|F5|IMPROVED_SPREAD|4.811|4.941|0.619|I|n=8, qg=11439 psf, ratio=0.356, depth=8 ft|n/a|SETTLEMENT|$213,000 / $91,043|
|W1|IMPROVED_SPREAD|4.598|4.746|0.719|I|n=25, qg=11445 psf, ratio=0.335, depth=8 ft|FS sliding 3.14; e 7.3 in; FS uplift 3.16|SETTLEMENT|$213,000 / $91,043|

Bearing used the least of Terzaghi, Meyerhof and Hansen drained site-specific results with groundwater-corrected unit weights. The strength combination checked footing shear/flexure; reported reinforcement is the larger of flexural demand and minimum ratios.