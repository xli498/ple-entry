[CONTINUATION SHEET]

WORK ORDER 74213 - FLEET DATA CENTER INCREMENT 2

BP-2 / AMENDMENT 0003
DRAWINGS:
REPLACE the revised sheets listed in the attached drawing index and delivered discipline bundles. The revisions correct the EOR design-review items and coordinated reference views.

DOCUMENT 00 01 15 LIST OF DRAWINGS
Replace: GI-001, C-101, S-101, S-102, S-201, S-301, S-501, S-502, M-101, M-102, M-301, M-401, M-501, M-502, E-101, and E-501, as identified in sheet_index.csv.
Add: M-503 74213-M503 MECHANICAL DETAILS - CHILLER PAD ANCHORAGE; S-202 74213-S202 BRACED BAY FRAMING ELEVATIONS.

BP-3
The BP-3 corrections are incorporated before advertisement. This package is not issued as a change to a solicitation; no continuation sheet or change number applies.

-- End of Continuation Sheet --
