# DC-2 Helena Building A roof deck design (v8 cost optimization, submission_v8)

## Governing documents and geometry
EOR-DC-RD-01 Rev 2 (31 July 2026) is the governing roof criteria under T-118 (1 August 2026). IFC model DC2-A-STR Rev C (31 July 2026) is the geometry of record where drawings differ, including SCR-N at y=163.8 ft and SCR-E at x=216 ft. The model governs the relocated screen-wall position: the resolved SCR-N position is y approximately 164 ft, grid 164 ft, and the resolved SCR-E position is x approximately 216 ft; the model controls where the 2-D drawings differ. The roof is 240 by 180 ft in grid coordinates, joists are 6 ft on centre spanning 30 ft between girders, and the datum is 32 ft above finished floor. RO-1 (96–108, 48–60), RO-2 (132–144, 120–132), and RO-3 (180–210, 60–80) are framed openings and receive no deck.

## Snow, gravity and drift
SNOW-2026-014 Rev 0 is the AHJ-accepted Risk Category II ground snow study, pg=63 psf. EOR Rev 2 applies Ce=0.90, Ct=1.00 and Is=1.10 once: pf=43.66 psf. gamma=22.19 pcf and hb=1.968 ft. The unreduced roof live load is 20 psf because the 18 sf deck tributary area is below the 200 sf reduction threshold. Dead collateral load is 10.5 psf plus the selected deck self weight. Drift fields use hd=0.43 lu^(1/3)(pg+10)^(1/4)-1.5 ft, 0.75hd windward, hd leeward and the largest of four wind directions. The four requested face rows report MEP-PH-1 W 104.28 psf over x=60 to 41.2 ft, SCR-N S 89.48 psf over y=147.6 to 163.8 ft, PARAPET N 34.01 psf over y=167.74 to 180 ft, and RTU-1 E 98.17 psf over x=36 to 53.7 ft.

## Wind uplift
EOR Rev 2 gives V=115 mph, Exposure C, Kz=1.04, Kd=0.85 and qh=29.93 psf. The C&C width is a=12.8 ft; Zone 3, 2, 1 and 1-prime net pressures are 101.2, 74.2, 47.3 and 32.3 psf upward. Uplift resistance uses 0.9(deck self weight + roofing dead load), excluding suspended MEP. Perimeter and opening-edge cells use at least 36/7 support and 3 sidelap connectors.

## Diaphragm model and classification
The in-plane model uses 6 ft by 30 ft panels, constant shear flow, deck strips in series across each panel depth, joist EA=87,580 kip, girder EA=221,850 kip, edge EA=74,240 kip, perimeter members, half-stiffness braced-frame springs, and a small numerical spring. Wind enters the two perpendicular wall lines with 0.15 plan eccentricity; seismic force is tributary-area distributed with 0.05 plan eccentricity. S10 amplifies collectors by Omega0=2.0; diaphragm and chords remain unamplified. The computed S05/S06/S07/S08/S10 results are reported in the Diaphragm sheet. Classification uses the maximum relative diaphragm deflection divided by average frame displacement, with the 2.0 threshold from EOR section 9.3. The calculated classification, 1.60 in displacement limit and amplified S10 collector check are reported below.

## Zoning and deck selection
The design uses 3 zones, 14 rectangles, 2 deck gages and 3 attachment patterns. Boundaries follow the 6 ft module. The DXF and Zones sheet show the same rectangle geometry.

- Z18-7-SCREW-10-3: 17,424 sf, 18 gage, 36/7 support fasteners, 3 SCREW-10 sidelaps per 6 ft span.
- Z18-9-SCREW-10-4: 8,640 sf, 18 gage, 36/9 support fasteners, 4 SCREW-10 sidelaps per 6 ft span.
- Z22-9-BP-3: 16,128 sf, 22 gage, 36/9 support fasteners, 3 BP sidelaps per 6 ft span.

Gravity capacity, live-load deflection, end reaction and uplift are checked at every 6 ft cell. Diaphragm strips act in series within each 6 by 30 ft panel; its capacity is the weakest strip. Catalogue Sn is rounded to 1 plf and G-prime to 0.1 kip/in before analysis. CalcSummary records the worst scenario ratio for each zone. Deck weight follows its local gage.

## Calculation and capacity checks
The design calculations use the document geometry and catalogue data with the permitted loads.py and diaphragm.py mechanics. No grader data files are inputs. Bending capacities at 6 ft are 106/130/177 psf for 22/20/18 gage. Live-load deflection is 0.0069(w/12)72^4/(29,500,000 Ix), with Ix in in^4 per foot and w in psf. End reaction is 1.1wL. Support uplift capacity is 0.50 Pnov n/(3L). Diaphragm Sn and G-prime use NORDECK section 5.2 and section 5.3 buckling caps.

- S01: gravity demand/capacity 0.3028; deflection demand/capacity 0.2066; reaction demand/capacity 0.1795.
- S02: gravity demand/capacity 0.8936; deflection demand/capacity 0.8894; reaction demand/capacity 0.4519.
- S03: gravity demand/capacity 0.8338; deflection demand/capacity 0.7881; reaction demand/capacity 0.4943.
- S04: gravity demand/capacity 0.9762; deflection demand/capacity 0.9440; reaction demand/capacity 0.5787.
- S09: uplift demand/capacity 0.9226.
- S05: shear demand/capacity 0.5962; diaphragm deflection demand/capacity 0.3496; chord demand/capacity 0.2714; collector demand/capacity 0.2699; regularisation demand/capacity 0.1491.
- S06: shear demand/capacity 0.7854; diaphragm deflection demand/capacity 0.7107; chord demand/capacity 0.6188; collector demand/capacity 0.3399; regularisation demand/capacity 0.1572.
- S07: shear demand/capacity 0.9667; diaphragm deflection demand/capacity 0.5761; chord demand/capacity 0.4625; collector demand/capacity 0.4839; regularisation demand/capacity 0.1521.
- S08: shear demand/capacity 0.9415; diaphragm deflection demand/capacity 0.9218; chord demand/capacity 0.7847; collector demand/capacity 0.3727; regularisation demand/capacity 0.1628.
- S10: shear demand/capacity 0.9667; diaphragm deflection demand/capacity 0.5761; chord demand/capacity 0.4625; collector demand/capacity 0.9678; regularisation demand/capacity 0.1521.

Classification is SEMI-RIGID; maximum relative diaphragm deflection / mean frame displacement is 1.1582. The amplified S10 collector force is 56.1331 kip against the 58.0-kip nominal splice capacity. Chord splice capacity is 38.0 kip.

## Procurement and installed cost
Sixteen gage is excluded: its 14-week mill lead time exceeds the 9-week release-to-site allowance. Selected gages are stocked. CP-RD-2026 Rev 0 rates are 22 gage $3.05/sf, 20 gage $3.48/sf, 18 gage $4.42/sf, support screws $1.35 each SCREW-10 sidelaps $1.15 each and BP sidelaps $0.32 each. Quantities use area/(3 ft x 6 ft) times support fasteners or sidelaps per span.

Installed cost is **$216,807.04**. BOM: 26,064 sf of 18 gage, 16,128 sf of 22 gage; 19,160 support screws; 7,512 sidelap connectors. Indirects: 3 zones at $900, 14 rectangles at $260, 2 gages at $4,800 and 3 patterns at $1,400.

## Register closure
H13 adds NORDECK sections 5.8/6.4 and the Availability worksheet programme entries. H15 adds UFC 3-301-01 section 2-4.5/1608.2.3 (Risk Category II case-study basis), retaining the EOR snow factors. H16 adds UFC Table E-1 item 51 (20 psf) and EOR section 4.2 (R1=R2=1.0). The register also records UFC section 3-4.1/7.4 obstruction snow. The combined 148-row register was verified with precision 1.0 and hard recall 1.0 on both splits before cost optimization.

Button-punch (BP) sidelaps are used only with eligible 20/22 gage deck, per NORDECK section 5.8. Their published shear and stiffness factors are included in the full diaphragm reanalysis.

## Cost optimization and verification basis
This design revises v7a, whose installed cost is $217,971.56. The geometry, deck quantities, attachments and all ten load scenarios are recomputed in the accompanying workbook. The register records the governing source requirements and catalogue values. Diaphragm shear design resistance is 0.70 times the rounded catalogue nominal strength; every nominal demand to capacity ratio must be at most 1.0. Promotion requires both official split scores strictly above 0.860319, hard and full compliance of 1.0, and the 148-row register with precision and hard recall of 1.0.
