# Basis of estimate

## Counting and issues
I applied C1-C9 of the Takeoff Criteria Manual. Each symbol is counted once; parent plans cross-referenced to E-231 series are empty, and the enlarged sheets govern those areas. E-001 defines the symbols. ADD-02 (2026-08-07) governs the A1 revision: two deleted R1 positions are removed and two R2 are added.

## Takeoff sources
R1/R2/R3/R4/R5/R6/J1/P1 were counted on E-201 through E-204 and enlarged E-231 through E-233 as listed in locations.csv. R7 includes the six PDU keynote devices from A-601 and the two drawn access-floor symbols on E-232/E-233. F1/F2/F3/F4/D1 are from E-211 plus keyed notes; F5 is from E-232/E-233. F4 is ceiling, F5 is access-floor, and D1 is carried as ceiling per the stated convention. Sheet-level totals and the condition split are in locations.csv; match-line repeats were counted on the scheduling side only.

## Unresolved symbols
Any plan graphic not matching an E-001 symbol is excluded under C3. In particular, equipment/cabinet graphics and non-legend plan marks on E-201-E-204, E-211 and E-231-E-233 are unresolved non-scheduled graphics, recorded in the basis by their sheet and grid-bay area (A1 for the hall takeoff matrix); no guessed type mark was created. The zero legend marks R8 and F6 are retained in takeoff.csv for auditability.

## Conditions and assemblies
Conditions come from A-102 and E-002: ordinary wall devices DRY-STUD; R4 is IG; R5 is DAMP; R5's keyed census is 16 CRAH units from A-601 plus four drawn R5 symbols on E-201; R6 is EMERGENCY; R7 is ACCESS-FLOOR; F4 is CEILING; F5 is ACCESS-FLOOR; D1 is CEILING. The chosen catalogue assemblies are: R1/R3/R6/F1/F2/F3/F4/J1 use BOX-4SQ-15 and, where a wall device requires it, RING-1G-58; R2 uses two duplex devices, a deeper box and two rings; R4 adds ACC-IG-CONDUCTOR; R5 uses the weather-resistant GFCI and listed box. R7 uses BOX-FLOOR-2G. P1 uses the listed pull box. F5 uses the access-floor detector and a 100 mm mounting box; F4 uses the ceiling detector and a 100 mm mounting box. D1 uses INS-DUCT-DET only because Division 23 furnishes the detector. DAMP requires an extra-duty while-in-use hood and gasketed plate under 26 20 00 2.3/2.5; the catalogue has no such item, so no hood or plate line is carried.

## Pricing and stock
Attribution rows are work-required quantities and their extended-price sum is the basket total. Purchase rows add 5 percent spare stock and round up to the printed carton. Prices use each item's required quantity band before stock rounding. Basket total: **$10,725.41**.

Mounting heights follow E-002; receptacles are 460 mm AFF to device centre unless scheduled otherwise.
