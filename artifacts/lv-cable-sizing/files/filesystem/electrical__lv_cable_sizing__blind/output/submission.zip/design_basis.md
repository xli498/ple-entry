```json
{
  "codes_of_record": {
    "nfpa70_edition": 2023,
    "ibc_edition": 2024,
    "adopted_by": "UFC 1-200-01, DoD Building Code, 1 September 2022, Change 4 (17 December 2024); editions fixed on IFC G-001",
    "precedence": "Most restrictive applicable requirement governs; current IFC documents only."
  },
  "environment": {
    "outdoor_design_dry_bulb_c": 42,
    "roof_ambient_c": 46,
    "earth_ambient_c": 27.446418,
    "soil_thermal_resistivity_k_m_w": 0.6,
    "solar_irradiance_w_m2": 1030,
    "encasement_thermal_resistivity_k_m_w": 0.55
  },
  "sources": {
    "outdoor_design_dry_bulb_c": "NOAA daily normals 1991-2020 USW00003145 DLY-TMAX-NORMAL; EDS-26 5.4",
    "roof_ambient_c": "EDS-26 Rev 4 5.4",
    "earth_ambient_c": "NOAA daily normals 1991-2020 USW00003145 DLY-TAVG-NORMAL; EDS-26 5.3.2",
    "soil_thermal_resistivity_k_m_w": "GEO-4210-T 2.2",
    "solar_irradiance_w_m2": "EDS-26 Rev 4 5.4",
    "encasement_thermal_resistivity_k_m_w": "GEO-4210-T 2.3"
  },
  "voltage_drop": {
    "start_point": "T-1 secondary lugs (point of government ownership)",
    "transformer_reset": false,
    "feeder_chain_pct": {
      "F-01": 2.575138,
      "F-02": 1.406536,
      "F-05": 2.581051,
      "F-06": 1.56796,
      "F-07": 2.769204,
      "F-10": 2.77737,
      "SE-1": 1.043377
    },
    "feeder_limit_pct": 3,
    "branch_limit_pct": 3,
    "total_limit_pct": 5
  },
  "cost": {
    "conductor_usd": 93438.30112,
    "termination_usd": 9609.32,
    "raceway_usd": 47589.6,
    "material_usd": 96947.38146,
    "labor_usd": 53689.83966,
    "total_usd": 150637.22112
  },
  "duct_assignment": {
    "SE-1": [
      "D1",
      "D2",
      "D5",
      "D6",
      "D9",
      "D10"
    ],
    "F-10": [
      "D4",
      "D8"
    ],
    "F-05": [
      "E1",
      "E2",
      "E3"
    ]
  },
  "mutual_heating_rise_k": {
    "SE-1": 31.094105,
    "F-10": 23.53036,
    "F-05": 1.535157
  },
  "duct_rise_by_position_k": {
    "SE-1": {
      "D1": 25.635899,
      "D2": 27.082852,
      "D5": 29.621919,
      "D6": 31.094105,
      "D9": 27.88486,
      "D10": 29.033698
    },
    "F-10": {
      "D4": 21.340845,
      "D8": 23.53036
    },
    "F-05": {
      "E1": 1.535157,
      "E2": 1.418133,
      "E3": 1.452561
    }
  }
}
```


# P-4210 | Building 4210 low-voltage design basis

## Codes, equipment and documents

Use NFPA 70 (2023) and IBC (2024), fixed at the 14 July 2025 design start and recorded on G-001. UFC 1-200-01 Change 4 adopts and modifies the IBC and redirects its NEC references to UFC 3-501-01, which cites NFPA 70. UFC 3-501-01 (27 Nov 2024) and UFC 3-520-01 (16 Jan 2025) supplement NFPA 70. Apply current EDS-26 Rev 4 and the most restrictive applicable requirement; where EDS is silent, apply UFC. Rev 2 and E-601 Rev A do not govern. Equipment, devices and listed lugs are fixed by the IFC drawings and equipment schedule. E-401 power-limited circuits are out of scope.

Cascadia Section 4, issue 2026-1 is the specified data of record. Meridian values do not govern. Specify 600 V single-conductor XHHW-2, 90 C wet and dry, sunlight resistant, compact stranded Class B. Use copper through #6 AWG and AL only where at least #4 AWG and AL/CU-listed; all scheduled terminations are listed for both materials. Use green insulated copper THHN/THWN-2 grounding conductors. Terminate with listed compression connectors, and identify each conductor by circuit at terminations and accessible enclosures. Keep parallel conductors identical in length, wire construction and termination method.

## Routes and thermal basis

The longest individual route dimension is not used as the circuit length. Each length is the sum of all segments on the power-plan E-RTE layer, E-618 rise/drop and 8 ft at each end, rounded up. Raceways are rigid steel, no smaller than Cascadia reference trade size. Use EDS fill and jam criteria. M-501-C sets 45 C for mechanical/fire-pump runs and 40 C elsewhere in scheduled interior routing; the UFC 25 C floor is not controlling. On changed routes, check maximum ambient and CCC again before installing.

The NOAA record has 366 normals: maximum daily normal high 106.8 F gives 42 C after conversion and rounding upward; EDS adds 4 K for 46 C at the roof. Average daily mean normal 76.0036 F plus 3 K gives 27.4464 C earth ambient. Neither the spring soil readings nor the obsolete 20 C value is used. GEO-4210-T specifies 0.60 K m/W thermal backfill around the encasement, not the 0.95 K m/W native dry soil; concrete is 0.55 K m/W. Use 100% load factor and no relief for intermittent load in duct calculations.

Ampacities are calculated under engineering supervision per NFPA 70 Article 310. Interior: corrected Cascadia 90 C heat-balance column, using sqrt((90 - Ta)/60) and sqrt(3/N) only when N > 3. Use two CCC in a 208 V line-to-line branch and three for a three-phase set. At the roof, use actual cable diameter, 14 W/(m2 K) film coefficient, 0.6 absorptivity, 1030 W/m2 direct solar and tray crowding multiplier 1 + 0.06(N - 3). Use the 60 C termination cap at OCPD ratings of 100 A and below and 75 C above, except when a lower listed lug rating applies. LP-1 limits F-07 to 60 C. Caps use uncorrected raceway data for conduit and ducts and free-air data for tray.

CT-R1 contains 18 CCC with a combined cable OD of 12.292 in including the grounds (limit 16.200 in). Lay single conductors in one layer, use tray-listed/marked wire, and do not add circuits without recalculation. The roof tray and ductbanks themselves are existing; the schedule assigns wire and existing spaces.

## Service entrance and duct-bank interaction

SE-1 is sized for the 2,000 A MSB-1 main bus, not its 1,600 A main device or 1,732 A connected load. It delivers 2088.67 A at its controlling position; the voltage-drop case instead uses the permitted 1,600 A breaker basis. The fixed demand input is not a substitute for main bus sizing. The service growth allowance is 15%; do not count the panelboard 15% spare ampacity a second time. Exclude the pump from aggregate demand, but not from its dedicated feeder calculation.

DB-1 has 10 available ducts of 12 shown. D11 is owner reserve; D12 is assigned to site lighting and excluded from the model. Allocate those ten positions between SE-1 and F-10 without exceeding either circuit’s lug count. DB-2 leaves E4 reserved for communications. E-619 calls for 30 in cover over both concrete envelopes. Use the section dimensions and position tables, not the approximate trench footage.

| Circuit | Ducts | Worst mutual rise (K) | Ampacity per set (A) |
|---|---|---:|---:|
| SE-1 | D1, D2, D5, D6, D9, D10 | 31.094 | 348.11 |
| F-10 | D4, D8 | 23.530 | 302.25 |
| F-05 | E1, E2, E3 | 1.535 | 336.00 |

Use the simplified Neher-McGrath formulation: sum insulation, PVC wall and air space, earth, and envelope correction; use outer envelope diameter sqrt(4WH/pi). Use R90 from the vendor temperature coefficient and convert ohm/kft to ohm/m. For each other occupied duct, multiply its three-phase heat (three times the square of connected amps per set times R90) by the earth image-distance coefficient and sum. The same-circuit sets and neighboring ATS/service sets all contribute. Check the hottest set on each circuit; do not use average mutual rise.
## Voltage drop and grounding
Start at nominal 480 V at T-1 secondary lugs (point of government ownership), not MSB-1 or the utility primary. Carry all feeder drop through K-13 and the integral DP-3 transformer at the same percentage of nominal; neither exceeds 1000 V. Assume no tap compensation. Use the scheduled PF with Cascadia AC resistance at 75 C and PVC reactance for tray and ducts, steel reactance inside. The end-of-line drop in volts is k × I × length in kft × (R × PF + X × sqrt(1 − PF²)) / sets, where k = sqrt(3) three-phase or 2 single-phase. Sum percentages referenced to each circuit’s own nominal voltage.
Ordinary feeder VD uses full nominal OCPD capacity. K-13 VD uses rated 225 kVA, with 6% transformer loss on the primary only. Motor and elevator loads use full-load amps; chillers and RTUs use nameplate rated amps; the drive uses maximum input amps. These are branches for VD only. Lighting and hard-wired appliances use connected load; receptacles use 80% of the device rating. Ampacity uses the equipment-class rules separately; OCPD is not a floor for the motor, drive, transformer, fire-pump, HVAC or elevator cases.
| Feeder endpoint | Path from T-1 | Drop (%) | Feeder margin to 3% | Inherited end circuits |
|---|---|---:|---:|---:|
| MSB-1 | SE-1 | 1.043 | 1.957 | 0 |
| MCC-1 | SE-1 / F-01 | 2.575 | 0.425 | 5 |
| DP-2 | SE-1 / F-02 | 1.407 | 1.593 | 0 |
| DP-3 | SE-1 / F-05 | 2.581 | 0.419 | 3 |
| K-13 | SE-1 / F-02 / F-06 | 1.568 | 1.432 | 0 |
| LP-1 | SE-1 / F-02 / F-06 / F-07 | 2.769 | 0.231 | 10 |
| ATS-1 | SE-1 / F-10 | 2.777 | 0.223 | 0 |

The 18 B-series circuits inherit upstream feeder drop: 10 from LP-1, five from MCC-1, three from DP-3. Each has the lesser of 3% or (5% minus upstream drop) available. The LP-1 chain has 2.231% remaining; upsize long 208 V branches to stay within that budget. Fire pump: 96 A running gives 1.339% cumulative against 5%; 543 A locked rotor gives 2.713% against 15%.
Size the EGC in every path from NFPA 70 Table 250.122 at the fixed breaker rating, including the owner-required service raceway allowance. When the phase size exceeds the same-material, same-set ampacity minimum for voltage drop, increase the EGC by the phase circular-mil ratio to the next available copper size. Tray EGCs are at least #4. New ground or bonding connections are to be made in accordance with the fixed system grounding design.
## Selection and installed cost
The selected large phase sizes are 4/0, 300 kcmil, 400 kcmil, 500 kcmil, 600 kcmil (5 total). Evaluate permissible material, size and set count; reject failures of thermal ampacity, lug fit, fill and voltage drop. Enumerate duct positions jointly and tray set combinations at the resulting common CCC. Compare installed costs with binary selection under the shared path and size constraints, with separate solves below and above the discount threshold. Parallel runs duplicate conduit only where interior conduit is in scope. The chosen set counts also put the package at 40,888 conductor-ft including copper EGC, so the 6% campus credit applies to conductor material and pulling labour, not conduit or terminations.
| Cost component | Material (USD) | Labour (USD) | Installed (USD) |
|---|---:|---:|---:|
| Conductors before adjustment | 74,931.96 | 24,470.49 | 99,402.45 |
| Campus quantity adjustment | -4,495.92 | -1,468.23 | -5,964.15 |
| Terminations | 5,105.26 | 4,504.06 | 9,609.32 |
| Interior raceway | 21,406.08 | 26,183.52 | 47,589.60 |
| Total | 96,947.38 | 53,689.84 | 150,637.22 |
