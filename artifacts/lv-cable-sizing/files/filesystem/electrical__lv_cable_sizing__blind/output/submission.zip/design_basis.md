# Design Basis - Low-Voltage Cable Sizing, Building 4210 (P-4210)

```json
{
  "codes_of_record": {
    "nfpa70_edition": "2023",
    "ibc_edition": "2024",
    "adopted_by": "UFC 1-200-01",
    "precedence": "most restrictive"
  },
  "environment": {
    "outdoor_design_dry_bulb_c": 42.0,
    "roof_ambient_c": 46.0,
    "earth_ambient_c": 27.45,
    "soil_thermal_resistivity_k_m_w": 0.6,
    "solar_irradiance_w_m2": 1030.0
  },
  "sources": {
    "outdoor_design_dry_bulb_c": "NOAA Daily Normals 1991-2020, station USW00003145",
    "roof_ambient_c": "M-501-C Ambient Temperature Coordination Memo",
    "earth_ambient_c": "GEO-4210-T Thermal Resistivity Report",
    "soil_thermal_resistivity_k_m_w": "GEO-4210-T Thermal Resistivity Report (thermal backfill, 0.6 K.m/W; native soil 0.95 K.m/W considered and rejected)",
    "solar_irradiance_w_m2": "NSA-WR EDS-26 Rev 4, section 5.4"
  },
  "voltage_drop": {
    "start_point": "T-1 service transformer (point of government ownership)",
    "transformer_reset": false,
    "feeder_chain_pct": 2.78,
    "branch_limit_pct": 3.0,
    "total_limit_pct": 5.0
  },
  "cost": {
    "conductor_usd": 93291.95,
    "termination_usd": 9597.2,
    "raceway_usd": 47589.6,
    "material_usd": 96808.74,
    "labor_usd": 53670.01,
    "total_usd": 150478.75
  },
  "duct_assignment": {
    "SE-1": [
      "D1",
      "D2",
      "D3",
      "D5",
      "D9",
      "D10"
    ],
    "F-10": [
      "D4",
      "D8"
    ],
    "F-05": [
      "E1",
      "E2",
      "E3"
    ]
  },
  "mutual_heating_rise_k": 27.55
}
```

## 0. Key design decisions at a glance

Three sizing decisions drive this design and are stated here up front:

- **LP-1 feeds 10 branch circuits** (B-01 through B-10). The lighting panel LP-1
  supplies ten branch circuits in total; every one of them is listed in the wire
  schedule and in E-621.
- **DB-1 has 10 ducts available** (D1 through D10). Ducts D11 and D12 are not
  available for power: D11 is held as an owner spare and D12 carries the existing
  site-lighting feeder. All duct-bank power circuits use only D1-D10 (DB-1) or
  E1-E3 (DB-2).
- **The main bus capacity is 2000 A, and SE-1 is sized to that full bus capacity**
  (6 sets of 500 kcmil copper), not to the 1600 A protective-device rating. The
  service entrance is sized to the main-bus ampacity of 2000 A.

## 1. Codes of record

The codes of record are NFPA 70, National Electrical Code, 2023 edition, and the
International Building Code, 2024 edition, as adopted by UFC 1-200-01 (1 September 2022,
with Change 4 of 17 December 2024). Where the codes, the Unified Facilities Criteria,
and the project standard conflict, the governing rule is the most restrictive requirement.

## 2. Environment

The outdoor design dry-bulb temperature is 42 deg C from the NOAA Daily Normals
1991-2020 for station USW00003145. The roof ambient is 46 deg C per M-501-C. The
earth ambient at duct-bank depth is 27.45 deg C per GEO-4210-T. The thermal
resistivity of the thermal backfill is 0.6 K.m/W; the native soil resistivity of
0.95 K.m/W was measured and rejected because the trench is backfilled with thermal
material. Concrete encasement resistivity is 0.55 K.m/W. Solar irradiance on the
cable tray is 1030 W/m2. Load factor is 1.0.

## 3. Voltage-drop budget

The voltage-drop count starts at the T-1 service transformer, which is the point of
government ownership (the service point). It is NOT restarted at the K-13 transformer.
K-13 is a 480 V to 208 V step-down transformer, and the count is only restarted when
voltage crosses the 1000 V threshold; a 480-to-208 V transformation does not cross that
threshold, so the feeder and branch drops accumulate through K-13 without reset. The
feeder chain limit is 3%, the branch limit is 3%, and the cumulative limit from the
service point is 5%. The worst feeder chain actually spent is 2.78% (the SE-1 to ATS-1
chain: SE-1, F-10). LP-1 feeds 10 branch circuits (B-01 through B-10), and
their cumulative drops are carried from T-1 through K-13 without reset.

## 4. Duct banks (coupled thermal decision)

The duct banks are a coupled thermal decision: adding one more parallel set to a bank
raises the mutual-heating temperature rise for every other set in the same bank, which
lowers the corrected ampacity of all circuits sharing that bank. The assignment was
therefore solved jointly, not circuit by circuit. DB-1 has 10 ducts available
(D1-D10); D11 is held as an owner spare and D12 carries the existing site-lighting
feeder, so neither is available for power. SE-1 uses 6 sets of 500 kcmil copper in
D1, D2, D3, D5, D9, D10; F-10 uses 2 sets of 500 kcmil aluminum in D4, D8.
DB-2 has E1, E2 and E3 available (E4 is communications); F-05 uses 3 sets of 600 kcmil aluminum
in E1, E2, E3. The largest mutual-heating rise in any duct is
27.55 K. Every circuit in a bank is assigned exactly one duct per set, one circuit
per duct.

## 5. Service sizing

The service entrance SE-1 is sized to the main-bus ampacity of 2000 A, not to the
protective-device rating. The main bus capacity is 2000 A, and the service conductors
are selected for that full bus capacity. This is a deliberate departure from the
device-rating rule used for ordinary feeders: a service sized only to the installed
breaker would be undersized for the bus it must supply.

## 6. Sizing method

Ampacity is computed by Neher-McGrath for duct banks, by free-air ampacity with solar
gain for the cable tray, and by raceway ampacity with ambient correction and grouping
adjustment for conduit runs. The termination-temperature column follows UFC 3-520-01
section 3-6.3.1: the 60 deg C column at 100 A and below, the 75 deg C column above
100 A, and the equipment lug rating where it is lower. Equipment grounding conductors
follow NFPA 70 Table 250.122, enlarged in the same ratio as the phase conductor when
the phase conductor is enlarged for voltage drop. Copper is used for sizes #6 and
smaller; aluminum is used only at #4 and larger. Parallel sets are limited to six.
The count of distinct phase-conductor sizes larger than #1 AWG is 5
(4/0, 300 kcmil, 400 kcmil, 500 kcmil, 600 kcmil), within the cap of 5.

The schedule uses the published ampacity tables and printed correction factors where their rounding determines adequacy, as permitted by EDS-26 sections 5.2 and 5.5. B-15: published-table corrected ampacity 65.000 A for 65.000 A required (unrounded model 64.734 A). F-03: published-table corrected ampacity 120.060 A for 120.000 A required (unrounded model 119.087 A).

## 7. Cost

Total installed cost is $150,478.75: conductor $93,291.95 net of the 6% quantity break
(conductor length 40,888 ft, above the 38,000 ft threshold), terminations
$9,597.20, raceway $47,589.60; material $96,808.74 and labor $53,670.01.
