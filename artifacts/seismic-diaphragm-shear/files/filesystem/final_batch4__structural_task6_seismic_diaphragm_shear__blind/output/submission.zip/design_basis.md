# Building B — seismic diaphragm shear and shear wall design basis

**Design format: LRFD.** Units are ft, kips, plf and inches unless noted. This delegated package is for Building B only.

## 1. Seismic basis

The governing record is SDC-02 Rev 2 §1: 2024 IBC as adopted in Montana, ASCE/SEI 7-22, ACI 318-19 and AISI S310. Building B is Risk Category III with **Ie = 1.25** (SDC-02 §2; OBD-CDDC-B §1.4), not the schematic Risk Category II. GEO-2026-071 §4 establishes Site Class D. The project USGS ASCE7-22 RiskCatIII/SiteClassD record gives **SDS = 0.44, SD1 = 0.24, S1 = 0.13, TL = 6 s**, and ASCE 7-22 §11.6 gives SDC D.

The effective seismic weight is **2171.0 kip**: 784 kip roof dead load, 45 kip phase-1 RTUs and 1342.0 kip equivalent roof wall weight from the FEMA/DAP-2 wall first-moment transfer. For diaphragm design, the X/Y diaphragm weights are 1399.9 and 1600.1 kip. The future case adds 16 kip for RTU-7F and RTU-8F, per OBD §2.2. Using ASCE 7-22 §12.8.1–12.8.3, Ta = 0.243 s, R = 4, Cs = 0.1375, Cvx = 1.0 and **V = 298.5 kip** for the base case.

## 2. Seismic force-resisting system

I selected **intermediate precast shear walls**: perimeter 8 in solid normal-weight precast panels acting as bearing-wall shear walls, with JC1 panel-joint connectors and panel base tie-downs. UFC 3-301-01 Table 3-1 A.6 / ASCE 7-22 Table 12.2-1 permits this system at SDC D to 40 ft; the 31 ft panel height is within the limitation. The factors are **R = 4, Ω0 = 2.5, Cd = 4**. SDC-02 §4 and the flexible-diaphragm footnote permit the Ω0 reduction to **2.0** for the collector design used here.

This is the cost-efficient permitted precast choice: ordinary precast is NP in SDC D in Table 3-1, while special precast requires JC3/ACI ITG-5.2 qualification and the $4,120/panel special premium. The selected system keeps the erected panels and avoids adding interior braced frames or shear walls. All four wall lines use WA1 at 6 ft spacing; the west line uses BA3 because recovered panel base tension is 66.9 kip, exceeding BA2's 66 kip LRFD capacity; south, north and east use BA2. JC1 is qualified for intermediate precast and is used at one connector per vertical joint; the panel segment checks and drift check govern whether a second connector is needed.

## 3. As-built geometry and conflicts resolved

The controlling plan is 240 × 180 ft, with deck +28 ft and parapet +31 ft (A-101 Rev 3; S-201 Rev 2; PC-301 Rev 2). The roof contains RO-1, 60 × 40 ft, and RO-2, 80 × 20 ft. The roof is a bare 1.5 in Type B deck on 6 ft joist spans, and S-201 defines twelve 60 × 60 ft net zones.

The erected geometry, not the record precast layout, was used under RFI-041, ERL-2026-08, A-101 Rev 3 note 6, PR-07 and DAP-2 §1. The south D-3 opening is 15.5 ft at x=78–93.5 ft; D-4 starts at x=109.5 ft, leaving the accepted 14.5 ft pier to D-5. North L-2 is 16 ft at x=154–170 ft, with its accepted shop-ticket location and sill/head spandrel. West EY-1 is 44 ft at y=66–110 ft, accepted under field change FC-018. GEO-2019-118 is an adjacent Parcel 4B report under a prior standard and was not used. The schematic RC II data were superseded by SDC-02/OBD. The phase-2 RTUs are a load case, not phase-1 scope.

## 4. Analysis and force cases

The calculations implement DAP-2 Rev 1: Stage A cracked, jointed panel springs and Stage B 10 ft membrane elements with 2 × 2 integration, A′ = 1,740 kip/in, deck G′ from BDS-2026, and the scanned openings removed. Wall springs are distributed by node length; chord, collector and drag members are two-node E=29,000 ksi bars. The Stage A routine reproduces DAP-2 Appendix A VP-1: kseg = 1,279.4 kip/in, end-joint shear coefficient 0.2630 and base moment coefficient 88.91 kip-in/kip for four 10 ft panels with three JC2 connectors in each joint; the selected Building B detail uses one JC1 at each joint.

Forces are the DAP-2 §6.3 envelope of flexible, rigid and semi-rigid models; deflection is recovered from the semi-rigid model. S01–S10 include the final base and future mass cases, ± accidental torsion and the required 100/30 cases; S11–S12 use the ERC-07 construction load at 0.5E with deck fastened only through X=180 ft. DAP-2 §6.4 applies 100% primary plus 30% companion demands in S05, S06, S09 and S10. The force workbook retains every case, flexible beam section reaction, and jointed panel-segment/member demand; rigid and semi-rigid results are obtained from the specified FE models and the design envelope.

## 5. Diaphragm and wall forces

The net roof diaphragm mass is **1399.9 kip / 1600.1 kip** for X/Y primary loading. The design diaphragm forces are **Fpx = 192.5 kip (X)** and **220.0 kip (Y)**, equivalent to **802 plf** over the 240 ft X span and **1222 plf** over the 180 ft Y span. The controlling zone envelope is **753 plf in Z12**; the zone pattern schedule is Z1 P5, Z2 P3, Z3 P3, Z4 P4, Z5 P5, Z6 P2, Z7 P2, Z8 P4, Z9 P4, Z10 P3, Z11 P3 and Z12 P4. The LRFD zone capacities are φSn = 333, 474, 663, 852 and 1,101 plf for P1–P5, so every zone has D/C ≤ 1.00.

Continuous CH-S/CH-N/CH-W/CH-E lines are shown on both plans, with C2 members on the long S/N chords and C1 members on the W/E chords and drag/collector runs. The roof-opening boundary lines are continuous. C1 drag/collector lines cross all openings 12 ft or wider; where the demand is lower, the plan still shows the required run rather than omitting it. The governing amplified collector/member demand and capacity are in CHORD_FORCES; the member check uses LRFD area/connection capacities and flags the required Ω0 combination.

## 6. Wall anchorage and parapet cantilever

FEMA P-2192-V1 §7.6.1 Step 1 is used for the wall face first-moment transfer. The 28 ft wall below deck contributes 1,400 plf and the 3 ft cantilever above deck contributes **316 plf**, for a full equivalent roof strip of **1716 plf**. ASCE 7-22 §12.11.2.1, SDC-02 §6 and UFC Figure 3-1 give the flexible-wall coefficient **ka = 2.0** for both directions (capped at 2.0). The resulting Fp is **858 plf**.

All four lines use WA1 at 6 ft spacing: demand 5.15 kip/anchor < 0.75(9.4) = 7.05 kip. Continuous ties and 60 ft span × 30 ft depth subdiaphragm modules give L/d = 2.0, below the 2.5 limit registered from ASCE 7-22 §12.11.2.2.1. Openings are bypassed by the continuous opening edge members.

## 7. Governing check on each wall line

The line-by-line base tie checks are: **S — BA2, 37.4/66 kip; N — BA2, 35.2/66 kip; W — BA3, 66.9/126 kip; E — BA2, 44.9/66 kip.** The wall-anchor check is WA1 at 6 ft, 5.15/7.05 kip per point, all four lines. The associated JC1 joint demands and every panel's base tension are listed in SEGMENT_CHECKS; each JC1 design demand is below φ(24) = 18 kip per connector. BA2 is φ(88) = 66 kip and BA3 is φ(168) = 126 kip. The panel checks are performed using the DAP-2 0.8-panel-length lever arm and coupling axial force.

The largest wall-line force envelope is S 154.5, N 161.7, W 162.1 and E 156.0 kip. The governing cases on those lines are S: S05, N: S09, W: S10, E: S08. The maximum amplified diaphragm top displacement is 0.68 in and maximum amplified wall-line drift is 0.17 in; their concurrent total is checked in WALL_FORCES against the EOR's 4.0 in attached-panel limit (SDC-02 §7). The maximum concurrent sum is 0.84 in. Story drift is also checked against ASCE 7-22 Table 12.12-1 for RC III all-other structures.

## 8. Cost

The installed lateral scope takeoff is in COST and follows PROC-114 Rev 2's quantity basis: net zone area, full assigned line length, actual panel-joint count × connectors, one base assembly per erected panel, anchors by spacing and SFRS premium per panel. The computed installed cost is **$369,527**, against the **$395,000** capital cap, leaving **$25,473**. The phase-2 equipment is a load case only and is not charged.

## 9. Alternatives rejected and document conflicts

* Ordinary precast was rejected because Table 3-1 marks it NP in SDC D. Special precast was rejected because its JC3/ACI ITG-5.2 qualification and premium are unnecessary for the permitted intermediate system.
* JC0 isolated panel piers were rejected because the lower jointed-segment stiffness and higher amplified drift do not provide the economical 4.0 in stability margin. JC2 was not selected because JC1 is qualified for intermediate walls and the calculated demands pass; one connector per joint is selected.
* P1/P2 were rejected in the controlling zones by the DAP-2 zone section means; P5 protects Z1 and Z5; P2 is adequate in Z6/Z7; P3/P4 cover the remaining zones at minimum installed cost. The traditional 12.10.1/.2 method was used because SDC-02 §5 expressly excludes the alternative procedure; the precast-diaphragm exception does not apply to this steel deck.
* Risk Category II, the adjacent-parcel 2019 geotechnical report, record-set opening sizes, and Building A archive values were rejected as superseded, nonapplicable or contradicted by the issued EOR response. The conflict resolution is recorded in design_record.json and the constraint register.

## 10. Installation / release notes

Provide the ERC-07 raking braces at 20 ft maximum spacing and 12 kip minimum capacity; remove them only after the roof deck is fastened in that bay and permanent panel connections are complete. Provide continuous ties at every subdiaphragm and do not substitute deck, member, connector, anchor or base marks without a revised LRFD check. The contractor's member connection design must verify C1/C2 local buckling, net section, weld/bolt strength and concrete/embedded-plate load transfer before fabrication.
