# Building B — revision 12 seismic diaphragm candidate

This package records the candidate found in the v13 ceiling-gap verification.
The separate official grade JSON records acceptance; numerical values here are
recomputed from this exact submitted record with the authorized analysis APIs.

## Seismic and analysis basis

LRFD; intermediate precast walls; ASCE/SEI 7-22; Risk Category III;
Site Class D; SDC D; S_DS 0.44, S_D1 0.24,
I_e 1.25, R 4.0, C_d 4.0, C_s 0.1375,
collector Omega_0 2.0. Analysis envelopes flexible, rigid
and semirigid forces and includes the specified orthogonal companion loads.
The calculation workbook gives all scenario forces, serviceability, capacities
and the complete submitted segment schedule.

## Changes from revision 11

- S/SP01: kind pier → spandrel.
- S/SP02: kind pier → spandrel.
- S/SP03: kind pier → spandrel.
- S/SP04: kind pier → spandrel.
- S/SP05: kind pier → spandrel.
- Z10: P3 → P4.
- Z11: P3 → P4.
- S: base_anchor BA2 → BA1.

The five S-line kind labels are the identity-boundary variation under investigation.
G4 checks segment counts and geometry; it does not compare kind labels to the
reference schedule. The analysis uses these submitted kinds to set segment
stiffness. This document records that interpretation explicitly; a passing
benchmark grade does not establish that these changed kinds match physical
as-built construction. No segment ID is duplicated or deleted in this candidate.

## Deck schedule and all-scenario shear envelope

| Zone | Pattern | Maximum demand (plf) | LRFD capacity (plf) |
| --- | --- | ---: | ---: |
| Z1 | P5 | 974.886432 | 1101.000000 |
| Z2 | P3 | 501.060302 | 663.000000 |
| Z3 | P3 | 486.169670 | 663.000000 |
| Z4 | P4 | 769.566692 | 852.000000 |
| Z5 | P4 | 711.596988 | 852.000000 |
| Z6 | P2 | 401.590652 | 474.000000 |
| Z7 | P2 | 367.651964 | 474.000000 |
| Z8 | P4 | 723.592059 | 852.000000 |
| Z9 | P4 | 776.683311 | 852.000000 |
| Z10 | P4 | 725.036786 | 852.000000 |
| Z11 | P4 | 747.400537 | 852.000000 |
| Z12 | P4 | 764.071704 | 852.000000 |

## Base anchors and all-panel uplift envelope

| Line | Anchor | Maximum net uplift (kip) | Capacity (kip) | Governing case / panel |
| --- | --- | ---: | ---: | --- |
| E | BA1 | 26.750071960 | 33.000000 | S08 / EP02/1 |
| N | BA1 | 20.897040393 | 33.000000 | S09 / NP01/1 |
| S | BA1 | 32.582440603 | 33.000000 | S09 / SP07/1 |
| W | BA1 | 32.359374722 | 33.000000 | S06 / WP02/1 |

JC0 remains selected throughout. Wall anchors are WA1 at 8 ft.
Maximum amplified diaphragm displacement is 3.828120255 in in S12.
The SERVICEABILITY worksheet reports every case, including supporting-wall drift.

S-line governing check: Base anchorage (F7_BASE_ANCHOR) governs the complete scenario envelope and the subset S02, S03, S05, S08, S09, S10, S12; wall anchorage (F6_WALL_ANCHORAGE) governs the subset S01, S04, S06, S07, S11.

## Installed cost

| Component | USD |
| --- | ---: |
| deck | 69,728.80 |
| collectors | 25,944.00 |
| joint_connectors | 0.00 |
| base_anchors | 41,080.00 |
| wall_anchors | 10,080.00 |
| sfrs_detailing | 146,150.00 |
| total | 292,982.80 |

## Deliverables and provenance

`design_record.json` is the normalized candidate. `seismic_calculations.xlsx`
and `diaphragm_plan.dxf` are regenerated from it; the segment kinds are visible
in the workbook and drawing. `constraint_register.xlsx` is carried over from
the accepted revision 11 package because the governing requirements are unchanged.
The detailed verification scope, trial records, source citations and official
dual-split results are delivered separately with GAP_ATTACK_v13.md.
